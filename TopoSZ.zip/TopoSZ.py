import sys
import os
sys.path.append(os.path.abspath('./src'))
from files_util import *
import time
def preprocessingDataSet(dataSet):
    l = 0
    if dataSet == "HeatedFlow" or dataSet == "HeatedFlow_heatMap":
        inputFileName = "HeatedFlow1298.vti"
        w = 150
        h = 450
        scalarField = 'velocityMagnitude'
        #normalizeVTK(os.path.join(inputDir, inputFileName), scalarField)
    if dataSet == "1950Control":
        inputFileName = "World_000.vti"
        w = 1440
        h = 720
        scalarField = 'velocityMagnitude'
        normalizeVTK(os.path.join(inputDir, inputFileName), scalarField)
    if "NYX" in dataSet:
        inputFileName = dataSet+'.vti'
        scalarField = "Scalars_"
        h,w,l = getDimsFromVTK(os.path.join(inputDir, inputFileName))

    if dataSet == "toyExample":
        inputFileName = "toyExample.vti"
        w = 200
        h = 200
        scalarField = 'Gaussian'
        
    if dataSet == 'foot':
        inputFileName = dataSet+'.vti'
        scalarField = "Scalars_"
        h,w,l = getDimsFromVTK(os.path.join(inputDir, inputFileName))
        #PersThr = 175

    if dataSet == 'Isabel':
        inputFileName = dataSet+'.vti'
        scalarField = "Scalars_"
        h,w,l = getDimsFromVTK(os.path.join(inputDir, inputFileName))
        #PersThr = 175

    if dataSet == 'Tangaroa':
        inputFileName = 'tangaroa.vti'
        scalarField = "Scalars_"
        h,w,l = getDimsFromVTK(os.path.join(inputDir, inputFileName))
        #PersThr = 175
   
    if dataSet == "Tornado":
        inputFileName = dataSet+'3d.vti'
        h,w,l = getDimsFromVTK(os.path.join(inputDir, inputFileName))
        #addMagnitude(os.path.join(inputDir, inputFileName))
        scalarField = 'velocityMagnitude'
    if dataSet == 'ViscousFingering':
        inputFileName = dataSet+'.vti'
        scalarField = "concentration"
        #normalizeVTK(os.path.join(inputDir, inputFileName), scalarField)
        h,w,l = getDimsFromVTK(os.path.join(inputDir, inputFileName))
    scalar = saveToSF(inputDir, inputFileName, scalarField)
    #plotM(scalar.reshape((l, w, h))[60,:,:])
    return w,h,l,inputFileName,scalarField

def runTopoSZandCheckFalseCases(inputDir, inputFileName, szTypes, globalErrs, PersThrs, w, h, l, scalarField, pdmt, cF):
    for szType in szTypes:
        firstTime = 1
        for globalErr in globalErrs:
            checking = []
            gErrs = []
            Fcnts = []
            PSNRs = []
            topoSZDir = os.path.join(inputDir, szType)
            make_dir(topoSZDir)
            for PersThr in PersThrs:
                #flag, loopID, gErr, Fcnt, psnr = calculateHomologyPreservingErrBound2(inputDir, inputFileName, PersThr, globalErr, w, h, l, szType, scalarField, pdmt, firstTime)
                flag, loopID, gErr, Fcnt, psnr,rto = calculateHomologyPreservingErrBound2(inputDir, inputFileName, PersThr, globalErr, w, h, l, szType, scalarField, pdmt, firstTime,1)
                checking.append([flag, loopID])
                gErrs.append(gErr)
                Fcnts.append(Fcnt)
                PSNRs.append(psnr)
                firstTime = 0
            #ratios = plotLineChart(topoSZDir, inputFileName, PersThrs, globalErr)
            globalDir = os.path.join(topoSZDir, 'GlobalErr_' + str(globalErr))
            print ([flag, loopID])
            print (gErr)
            print (Fcnt)
            print ("PSNR: " +str(psnr))
            print ("Compression Ratio: "+ str(rto))
            #writeCmpInfo(globalDir, ratios, Fcnts, PSNRs, gErrs)
            #writeCheckingFile(topoSZDir, globalErr, checking, ratios, PersThrs)
            if cF:
                for PersThr in PersThrs:
                    globalDir = os.path.join(topoSZDir, 'GlobalErr_' + str(globalErr))
                    outDir = os.path.join(globalDir, 'PersThr_' + str(PersThr))
                    cleanFolder(outDir)

def comparisonWithOtherCmpTopoSZ(inputDir, inputFileName, globalErrs, szType, PersThr, w, h, l, scalarField, pdmt):
    checking = []
    gErrs = []
    Fcnts = []
    PSNRs = []
    ratios = []
    topoSZDir = os.path.join(inputDir, szType+'-Other')
    firstTime = 1
    for globalErr in globalErrs:
        flag, loopID, gErr, Fcnt, psnr,rto = calculateHomologyPreservingErrBound2(inputDir, inputFileName, PersThr, globalErr, w, h, l, szType, scalarField, pdmt, firstTime,1)
        checking.append([flag, loopID])
        gErrs.append(gErr)
        Fcnts.append(Fcnt)
        PSNRs.append(psnr)
        ratios.append(rto)
        firstTime = 0
    writeCmpInfo(topoSZDir, ratios, Fcnts, PSNRs, gErrs)
          
                    
def runOtherCmpAndCheckFalseCases(inputDir, inputFileName, w, h, l, globalErrs):
    comparisonWithOtherCmp(inputDir, inputFileName, w, h, l, globalErrs, "ClassicSZ")

if __name__ == '__main__':

    #====2D datasets====
    dataSet = "1950Control"
    #dataSet = "HeatedFlow"
    #dataSet = "toyExample"
    

    #====3D datasets====
    #dataSet = "NYX100"
    #dataSet = "foot"
    #dataSet = "Tornado"
    #dataSet = 'ViscousFingering'
    #dataSet = 'Tangaroa'
    dataSet = 'Isabel'
   

    inputDir = os.path.join('./data', dataSet)
    w,h,l,inputFileName,scalarField = preprocessingDataSet(dataSet)
    
   
    # pdmt = 1: caluclate persistence diagram and merge tree for comparison.
    # firstTime = 1: used to mark the first calculation.
    #globalErrs = [0.001,0.005, 0.01, 0.1]
    #PersThrs = [0.0001, 0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19]    
    # runningTime1: calculate PD
    # runningTime2: simplification
    # runningTime3: contour tree
    # runningTime4: error bound calculation
    # runningTime5: customize SZ

    pdmt = 1
    cF = 0
    szTypes = [ "lbub"]
    globalErrs = np.array([0.001,  0.004, 0.008,  0.012, 0.016,0.02])
    #globalErrs = np.array([  0.008, 0.012, 0.016,0.02])
    globalErrs = np.array([0.012])
    PersThrs = np.array(range(1, 11))*0.02
    #PersThrs = [0.4]
    PersThrs = [0.02]
    globalErrs = [0.006]
    PersThrs = [0.06]

    print ("====dataSet: "+ dataSet + "=====")
    print (h,w,l)
    #print (globalErrs)
    #print (PersThrs)
    
    #runTopoSZandCheckFalseCases(inputDir, inputFileName, szTypes, globalErrs, PersThrs, w, h, l, scalarField, pdmt, cF)
    #runOtherCmpAndCheckFalseCases(inputDir, inputFileName, w, h, l, globalErrs)
    #comparisonWithTopoCmp(inputDir, inputFileName, PersThrs, globalErrs, scalarField, pdmt)
    #comparisonWithCmpViaDist(inputDir, PersThrs, globalErrs)
   


    ## Comparison between TopoSZ, SZ, ZFP, FPZIP, and TThresh
    globalErrs = []
    cnt = 8
    for i in range(1, cnt):
        globalErrs.append(1/10**(cnt-i))
    globalErrs = [1e-05, 0.00005, 0.0001, 0.0005, 0.001, 0.005, 0.01, 0.05, 0.1]
    globalErrs = [0.006]
    print (globalErrs)
    PersThr = 0.12
    pdmt = 0

    #comparisonWithOtherCmpTopoSZ(inputDir, inputFileName, globalErrs, "lbub", PersThr, w, h, l, scalarField, pdmt)
    #comparisonWithOtherCmp(inputDir, inputFileName, w, h, l, globalErrs, "ClassicSZ")
    #globalErrs = [0.00005, 0.0002, 0.0005, 0.002, 0.005, 0.03, 0.1, 0.1, 0.4, 0.5]
    #comparisonWithOtherCmp(inputDir, inputFileName, w, h, l, globalErrs, "ZFP")
    globalErrs=[ 24, 22, 21, 19, 18, 15, 13,12, 11]
    globalErrs= [15]
    #comparisonWithOtherCmp(inputDir, inputFileName, w, h, l, globalErrs, "FPZIP")
    globalErrs = [0.000005,0.00001,0.00005, 0.0001,0.0005,0.0013, 0.002, 0.01, 0.03,0.04,0.1,0.11]
    globalErrs = [0.0005]
    comparisonWithOtherCmp(inputDir, inputFileName, w, h, l, globalErrs, "TTHRESH")

    
    
    globalErrs = [0.001,0.005, 0.01, 0.1]
    PersThrs = [0.0001, 0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19]
   
    globalErrs = []
    cnt = 8
    for i in range(1, cnt):
        globalErrs.append(1/10**(cnt-i))
    #plotLineChartforOtherCmps(inputDir, ["ClassicSZ", "ZFP", "FPZIP"], globalErrs)
    #comparingEBAndUblb(os.path.join(inputDir, 'lbub'), os.path.join(inputDir, 'eb'), globalErrs, PersThrs)
    #plotHeatMap(inputDir, PersThrs, globalErrs)
    #plotLineChartCompressionRatioVSOthers(inputDir, PersThrs, globalErrs)
