from functions_util import *
PERT = 0.00000001
from plot_util import *

def calculateErrBound(inputDir, scalar):
    sortSF = sorted(scalar)
    idx = sorted(range(len(scalar)), key=lambda k: scalar[k])
    errs = np.zeros(len(scalar))
    print ("Calculate error bound...")
    for i in range(len(scalar)):
        if i == 0:
            err = sortSF[i+1] - sortSF[i]
        elif i == len(scalar)-1:
            err = sortSF[i] - sortSF[i-1]
        else:
            err = min(sortSF[i+1] - sortSF[i], sortSF[i] - sortSF[i-1])
    errs[idx[i]]=err
    outDir = os.path.join(inputDir, 'fullOrder')
    saveToDatDouble(errs, os.path.join(outDir, 'err.dat'))

def calculateErrBoundV1(segmID, scalarOriginal, PersThr, critsID, globalErr, outDir):
    scnt = len(set(segmID))
    spans = []
    for i in range(scnt):
        spans.append([])
    for i in range(len(segmID)):
        spans[segmID[i]].append(scalarOriginal[i])
    spansVal = []
    for i in range(scnt):
        spansVal.append([min(spans[i]), max(spans[i])])
    spansVal = np.array(spansVal)
    upperErr = []
    lowerErr = []
    errs = []
    for i in range(len(scalarOriginal)):
        maxR = spansVal[segmID[i], 1]
        minR = spansVal[segmID[i], 0]
        upperErr.append(maxR)
        lowerErr.append(minR)
        err = min(maxR-scalarOriginal[i]-PERT, scalarOriginal[i]-minR-PERT)
        if err < 0:
            err = 0
        if err>globalErr:
            err = globalErr
        errs.append(err)
    errs = np.array(errs)
    errs[critsID] = 0
    for i in range(len(critsID)):
        upperErr[critsID[i]] = scalarOriginal[critsID[i]]
        lowerErr[critsID[i]] = upperErr[critsID[i]]
        
    saveToDatFloat32(np.array(upperErr), os.path.join(outDir, 'UpperErr1.dat'))
    saveToDatFloat32(np.array(lowerErr), os.path.join(outDir, 'LowerErr1.dat'))
    return errs, np.array(upperErr), np.array(lowerErr)

def calculateErrBoundUbLB(segmID, scalarOriginal, PersThr, critsID, globalErr, outDir):
    ts = time.time()
    scnt = len(set(segmID))
    spans = []
    for i in range(scnt):
        spans.append([])
    for i in range(len(segmID)):
        spans[segmID[i]].append(scalarOriginal[i])
    spansVal = []
    for i in range(scnt):
        spansVal.append([min(spans[i]), max(spans[i])])
    spansVal = np.array(spansVal)
    upperErr = []
    lowerErr = []
    for i in range(len(scalarOriginal)):
        maxR = spansVal[segmID[i], 1]
        minR = spansVal[segmID[i], 0]
        upperErr.append(maxR)
        lowerErr.append(minR)
    for i in range(len(critsID)):
        upperErr[critsID[i]] = scalarOriginal[critsID[i]]
        lowerErr[critsID[i]] = upperErr[critsID[i]]
    t4 = time.time()-ts
    saveToDatFloat32(np.array(upperErr), os.path.join(outDir, 'UpperErr1.dat'))
    saveToDatFloat32(np.array(lowerErr), os.path.join(outDir, 'LowerErr1.dat'))
    return np.array(upperErr), np.array(lowerErr), t4

def getRanges(l, r):
    maxv = max(l)
    minv = min(l)
    stepv = (maxv-minv)/(r+1)
    rng = [minv]
    for i in range(r):
        rng.append(minv+stepv*(i+1))
    rng.append(maxv)
    return rng

def findThunk(sf, rngs):
    for i in range(len(rngs)):
        if sf>=rngs[i][0] and sf<rngs[i][1]:
            return i
    return len(rngs)-1

def calculate_eblb_3d_new(outDir, segmID, segmID_d, sfo, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h, ll, r, PersThr):
    r=r
    print ("\n\n\nXXXXX")
    scnt = len(set(segmID))
    Ncnt = len(segmID)
    smpSegms = []
    l = set(critsID_d)-set(critsID)
    for i in range(len(l)):
        idx = list(critsID_d).index(list(l)[i])
        if critsType_d[idx]==0 or critsType_d[idx]==3:
            if segmID[critsID_d[idx]] not in smpSegms:
                smpSegms.append(segmID[critsID_d[idx]])
    l = set(critsID)-set(critsID_d)
    for i in range(len(l)):
        idx = list(critsID).index(list(l)[i])
        if critsType[idx]==0 or critsType[idx]==3:
            if segmID[critsID[idx]] not in smpSegms:
                smpSegms.append(segmID[critsID[idx]])
    l = set(critsID).intersection(set(critsID_d))
    for i in range(len(l)):
        idx1 = list(critsID).index(list(l)[i])
        idx2 = list(critsID_d).index(list(l)[i])
        if critsType[idx1] != critsType_d[idx2]:
            if critsType[idx1] in [0,3] or critsType_d[idx2] in [0,3]:
                smpSegms.append(segmID[critsID[idx1]])

    segms = []
    ub2 = ub.copy()
    lb2 = lb.copy()
    scnt = len(set(segmID))
    for i in range(scnt):
        segms.append([])
    for i in range(len(segmID)):
        segms[segmID[i]].append(i)

    Chcnt = 0
    for segm in smpSegms:
        X = np.array(segms[segm])[np.argsort(sfo[segms[segm]])]
        Chcnt += len(X)
        Xs = np.array_split(X, 2**r+1)
        for i in range(len(Xs)):
            if len(Xs[i])>0:
                ub2[Xs[i]] = max(sfo[Xs[i]])
                lb2[Xs[i]] = min(sfo[Xs[i]])
    ub2[critsID] = sfo[critsID]
    lb2[critsID] = ub2[critsID]
    print (str(Chcnt)+'/'+str(Ncnt)+'  '+str(Chcnt/Ncnt))
    saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
    saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
    return ub2, lb2

def calculate_eblb_new(outDir, segmID, segmID_d, sfo, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, r, PersThr):
    M = np.array(list(range(w*h))).reshape(h,w)
    smpSegms = []
    l = set(critsID)-set(critsID_d)
    sds = []
    for i in range(len(l)):
        idx = list(critsID).index(list(l)[i])
        if critsType[idx]==0 or critsType[idx]==3:
            if segmID[critsID[idx]] not in smpSegms:
                smpSegms.append(segmID[critsID[idx]])
                saddles = list(edges[np.where(edges == idx)[0]][0])
                saddles.remove(idx)
                saddle = critsID[saddles[0]]
                sds.append(saddle)
                
    if len(smpSegms)>0:
        scnt = len(set(segmID))
        segms = []
        ub2 = ub.copy()
        lb2 = lb.copy()
        scnt = len(set(segmID))
        for i in range(scnt):
            segms.append([])
        for i in range(len(segmID)):
            segms[segmID[i]].append(i)

        for i in range(len(smpSegms)):
            segm = smpSegms[i]
            sr = segms[segm]
            saddle = sds[i]
            snb = segms[segmID[saddle]]
            sortedRegion = list(set(sr+snb))
            X = np.array(sortedRegion)[np.argsort(sfo[sortedRegion])]
            Xs = np.array_split(X, 2**r+1)
            for i in range(len(Xs)):
                if len(Xs[i])>0:
                    ub2[Xs[i]] = max(sfo[Xs[i]])
                    lb2[Xs[i]] = min(sfo[Xs[i]])
        ub2[critsID] = sfo[critsID]
        lb2[critsID] = ub2[critsID]
        saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
        saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
        return ub2, lb2
    
   
    scnt = len(set(segmID_d))
    smpSegms = []
    l = set(critsID_d)-set(critsID)
    sds = []
    for i in range(len(l)):
        idx = list(critsID_d).index(list(l)[i])
        if critsType_d[idx]==0 or critsType_d[idx]==3:
            if segmID_d[critsID_d[idx]] not in smpSegms:
                smpSegms.append(segmID_d[critsID_d[idx]])
                saddles = list(edges_d[np.where(edges_d == idx)[0]][0])
                saddles.remove(idx)
                saddle = critsID_d[saddles[0]]
                sds.append(saddle)
    segms = []
    ub2 = ub.copy()
    lb2 = lb.copy()
    scnt = len(set(segmID_d))
    for i in range(scnt):
        segms.append([])
    for i in range(len(segmID_d)):
        segms[segmID_d[i]].append(i)

    for i in range(len(smpSegms)):
        segm = smpSegms[i]
        sr = segms[segm]
        saddle = sds[i]
        #snb = segms[segmID_d[saddle]]
        snb = getNeighborOfSaddle(M, saddle, w, h,3)
        sortedRegion = list(set(sr+snb))
        X = np.array(sortedRegion)[np.argsort(sfo[sortedRegion])]
        Xs = np.array_split(X, 2**r+1)
        for i in range(len(Xs)):
            if len(Xs[i])>0:
                ub2[Xs[i]] = max(sfo[Xs[i]])
                lb2[Xs[i]] = min(sfo[Xs[i]])
    ub2[critsID] = sfo[critsID]
    lb2[critsID] = ub2[critsID]
    saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
    saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
    return ub2, lb2

def getLargerSR(sr,M, saddle, w, h, ll,r):
    ssr = sr.copy()
    for i in range(len(ssr)):
        if ll>0:
            snb = getNeighborOfSaddle3d(M, ssr[i], w, h, ll,r)
        else:
            snb = getNeighborOfSaddle(M, ssr[i], w, h,r*2)
        sr = list(set(sr+snb))
    return sr

def calculate_eblb(outDir, segmID, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType_d, edges_d, w, h, r, PersThr):

    
    M = np.array(list(range(w*h))).reshape(h,w)
    segms = []
    ub2 = ub.copy()
    lb2 = lb.copy()
    ll = np.zeros(len(segmID))
    scnt = len(set(segmID))
    for i in range(scnt):
        segms.append([])
    for i in range(len(segmID)):
        segms[segmID[i]].append(i)
    l = set(critsID_d)-set(critsID)
    for i in range(len(l)):
        idx = list(critsID_d).index(list(l)[i])
        if critsType_d[idx]==0 or critsType_d[idx]==3:
            sortedRegion = segms[segmID[critsID_d[idx]]]
            saddles = list(edges_d[np.where(edges_d == idx)[0]][0])
            saddles.remove(idx)
            saddle = critsID_d[saddles[0]]
            sortedRegion.append(saddle)
            maxR = max(scalarOriginal[sortedRegion])
            minR = min(scalarOriginal[sortedRegion])
            if maxR-minR < PersThr:
                snb = getNeighborOfSaddle(M, saddle, w, h,r)
                sr = list(sortedRegion)
                sortedRegion = list(set(sr+snb))
                sortedRegions = sorted(sortedRegion)
                
                ub2[sortedRegion] = maxR
                lb2[sortedRegion] = minR
            else:
                snb = getNeighborOfSaddle(M, saddle, w, h,r)
                sr = list(sortedRegion)
                sortedRegion = list(set(sr+snb))
                sortedRegions = sorted(sortedRegion)
                scnt = r+1
                ub2, lb2 = splitRegion(sortedRegions, scnt, ub2, lb2,scalarOriginal, PersThr)       
            ll[sortedRegion] = 1
    #plotM(ll.reshape(h,w))
    saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
    saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
    return ub2, lb2

def calculate_eblb_3d_new0(outDir, segmID, segmID_d, sfo, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, ll, r, PersThr):
    if ll>0:
        M = np.array(list(range(w*h*ll))).reshape((ll,w,h))
    else:
        M = np.array(list(range(w*h))).reshape(h,w)
    smpSegms = []
    sds = []
    Ncnt = len(segmID)
    Chcnt  = 0
    l = set(critsID)-set(critsID_d)
    for i in range(len(l)):
        idx = list(critsID).index(list(l)[i])
        if critsType[idx]==0 or critsType[idx]==3:
            if segmID[critsID[idx]] not in smpSegms:
                smpSegms.append(segmID[critsID[idx]])
                saddles = list(edges[np.where(edges == idx)[0]][0])
                saddles.remove(idx)
                saddle = critsID[saddles[0]]
                sds.append(saddle)
    if len(smpSegms)>0:
        print ("False Negative Detected!")
        scnt = len(set(segmID))
        segms = []
        ub2 = ub.copy()
        lb2 = lb.copy()
        scnt = len(set(segmID))
        for i in range(scnt):
            segms.append([])
        for i in range(len(segmID)):
            segms[segmID[i]].append(i)

        #MM = np.zeros(len(segmID))
        for i in range(len(smpSegms)):
            segm = smpSegms[i]
            sr = segms[segm]
            saddle = sds[i]
            if ll>0:
                snb = getNeighborOfSaddle3d(M, saddle, w, h, ll, int(r))              
            else:
                snb = getNeighborOfSaddle(M, saddle, w, h,int(r))
            #sr  = getLargerSR(sr,M, saddle, w, h, ll, int(r/100))
            #snb = segms[segmID[saddle]]
            sortedRegion = list(set(sr+snb))
            #sortedRegion = sr
            X = np.array(sortedRegion)[np.argsort(sfo[sortedRegion])]
            Xs = np.array_split(X, 2**r+1)
            print (Xs)
            Chcnt += len(X)
            for i in range(len(Xs)):
                if len(Xs[i])>0:
                    ub2[Xs[i]] = max(sfo[Xs[i]])
                    lb2[Xs[i]] = min(sfo[Xs[i]])
        ub2[critsID] = sfo[critsID]
        lb2[critsID] = ub2[critsID]
        #plotM(MM.reshape(w,h))
        saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
        saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
        print (str(Chcnt)+'/'+str(Ncnt)+'  '+str(Chcnt/Ncnt))
        return ub2, lb2
    r = 2*r
    scnt = len(set(segmID_d))
    smpSegms = []
    l = set(critsID_d)-set(critsID)
    sds = []
    for i in range(len(l)):
        idx = list(critsID_d).index(list(l)[i])
        if critsType_d[idx]==0 or critsType_d[idx]==3:
            if segmID_d[critsID_d[idx]] not in smpSegms:
                smpSegms.append(segmID_d[critsID_d[idx]])
                saddles = list(edges_d[np.where(edges_d == idx)[0]][0])
                saddles.remove(idx)
                saddle = critsID_d[saddles[0]]
                sds.append(saddle)
    segms = []
    ub2 = ub.copy()
    lb2 = lb.copy()
    scnt = len(set(segmID_d))
    for i in range(scnt):
        segms.append([])
    for i in range(len(segmID_d)):
        segms[segmID_d[i]].append(i)
    print (scnt)
    print (len(smpSegms))

    for i in range(len(smpSegms)):
        segm = smpSegms[i]
        sr = segms[segm]
        saddle=sds[i]
        if ll>0:
            snb = getNeighborOfSaddle3d(M, saddle, w, h, ll,int(r/2))
        else:
            snb = getNeighborOfSaddle(M, saddle, w, h,int(r/2))
        #snb = segms[segmID_d[saddle]]
        sortedRegion = list(set(sr+snb))
        X = np.array(sortedRegion)[np.argsort(sfo[sortedRegion])]
        Chcnt += len(X)
        Xs = np.array_split(X, 2**r+1)
        for i in range(len(Xs)):
            if len(Xs[i])>0:
                ub2[Xs[i]] = max(sfo[Xs[i]])
                lb2[Xs[i]] = min(sfo[Xs[i]])
    ub2[critsID] = sfo[critsID]
    lb2[critsID] = ub2[critsID]
    saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
    saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
    print (str(Chcnt)+'/'+str(Ncnt)+'  '+str(Chcnt/Ncnt))
    return ub2, lb2

def calculate_eblb_3d_new02(outDir, segmID, segmID_d, sfo, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, ll, r, PersThr, lbda, rd):
    print ("\n\nrd:"+str(rd))
    print ("r:"+str(r))
    print ("lbda:"+str(lbda))
    if ll>0:
        M = np.array(list(range(w*h*ll))).reshape((ll,w,h))
    else:
        M = np.array(list(range(w*h))).reshape(h,w)
    smpSegms = []
    cpIds = []
    sds = []
    segTypes = []
    Ncnt = len(segmID)
    Chcnt  = 0
    l = set(critsID)-set(critsID_d)
    for i in range(len(l)):
        idx = list(critsID).index(list(l)[i])
        if critsType[idx]==0 or critsType[idx]==3:
            if segmID[critsID[idx]] not in smpSegms:
                smpSegms.append(segmID[critsID[idx]])
                saddles = list(edges[np.where(edges == idx)[0]][0])
                saddles.remove(idx)
                saddle = critsID[saddles[0]]
                sds.append(saddle)
                segTypes.append(critsType[idx])
                cpIds.append(critsID[idx])
    if len(smpSegms)>0:
        rd=r
        print ("False Negative Detected!")
        scnt = len(set(segmID))
        segms = []
        ub2 = ub.copy()
        lb2 = lb.copy()
        scnt = len(set(segmID))
        for i in range(scnt):
            segms.append([])
        for i in range(len(segmID)):
            segms[segmID[i]].append(i)

        #MM = np.zeros(len(segmID))
        for i in range(len(smpSegms)):
            segm = smpSegms[i]
            sr = segms[segm]
            sss = segms[segm]
            saddle = sds[i]
            if ll>0:
                snb = getNeighborOfSaddle3d(M, saddle, w, h, ll, lbda)              
            else:
                snb = getNeighborOfSaddle(M, saddle, w, h,lbda)

            if r>1:
                sr  = getLargerSR(sr,M, saddle, w, h, ll, 1)

            if r>20:
                rg1 = find3DRegion(M,snb)
                rg2 = find3DRegion(M,list(set(sr)-set(sss)))
                rg3 = find3DRegion(M,sss)
                sad = get3DPosOfSaddle(M,saddle)
                fig = plt.figure()
                ax = fig.add_subplot(projection='3d')
                ax.scatter(rg1[:,0], rg1[:,1], rg1[:,2], color="red",alpha=0.1)
                ax.scatter(rg2[:,0], rg2[:,1], rg2[:,2], color="yellow",alpha=0.1)
                ax.scatter(rg3[:,0], rg3[:,1], rg3[:,2], color="blue",alpha=0.1)
                ax.scatter([sad[0]], [sad[1]], [sad[2]], color="green", marker='^',s=100)
                plt.show()
            #snb = segms[segmID[saddle]]
            sortedRegion = list(set(sr+snb))
            #MM[sortedRegion] = 1
            #sortedRegion = sr
            X = np.array(sortedRegion)[np.argsort(sfo[sortedRegion])]
            Xs = np.array_split(X, 2**r+1)
            Chcnt += len(X)
            for i in range(len(Xs)):
                if len(Xs[i])>0:
                    ub2[Xs[i]] = max(sfo[Xs[i]])
                    lb2[Xs[i]] = min(sfo[Xs[i]])
        ub2[critsID] = sfo[critsID]
        lb2[critsID] = ub2[critsID]
        #plotM(MM.reshape(h,w))
        saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
        saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
        print (str(Chcnt)+'/'+str(Ncnt)+'  '+str(Chcnt/Ncnt))
        return ub2, lb2, rd
    scnt = len(set(segmID_d))
    smpSegms = []
    l = set(critsID_d)-set(critsID)
    sds = []
    for i in range(len(l)):
        idx = list(critsID_d).index(list(l)[i])
        if critsType_d[idx]==0 or critsType_d[idx]==3:
            if segmID_d[critsID_d[idx]] not in smpSegms:
                smpSegms.append(segmID_d[critsID_d[idx]])
                saddles = list(edges_d[np.where(edges_d == idx)[0]][0])
                saddles.remove(idx)
                saddle = critsID_d[saddles[0]]
                sds.append(saddle)
    segms = []
    ub2 = ub.copy()
    lb2 = lb.copy()
    scnt = len(set(segmID_d))
    for i in range(scnt):
        segms.append([])
    for i in range(len(segmID_d)):
        segms[segmID_d[i]].append(i)
    print ("\n\n\nradius")
    print (lbda+r-rd)

    for i in range(len(smpSegms)):
        segm = smpSegms[i]
        sr = segms[segm]
        saddle=sds[i]
        if ll>0:
            snb = getNeighborOfSaddle3d(M, saddle, w, h, ll,lbda+r-rd)
        else:
            snb = getNeighborOfSaddle(M, saddle, w, h,lbda+r-rd)
        #snb = segms[segmID_d[saddle]]
        sortedRegion = list(set(sr+snb))
        X = np.array(sortedRegion)[np.argsort(sfo[sortedRegion])]
        Chcnt += len(X)
        Xs = np.array_split(X, 2**r+1)
        for i in range(len(Xs)):
            if len(Xs[i])>0:
                ub2[Xs[i]] = max(sfo[Xs[i]])
                lb2[Xs[i]] = min(sfo[Xs[i]])
    ub2[critsID] = sfo[critsID]
    lb2[critsID] = ub2[critsID]
    saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
    saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
    print (str(Chcnt)+'/'+str(Ncnt)+'  '+str(Chcnt/Ncnt))
    return ub2, lb2, rd

def calculate_eblb_3d(outDir, segmID, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h, l, r, PersThr):
    M = np.array(list(range(w*h*l))).reshape((l,h,w))
    segms = []
    ub2 = ub.copy()
    lb2 = lb.copy()
    ll = np.zeros(len(segmID))
    scnt = len(set(segmID))
    for i in range(scnt):
        segms.append([])
    for i in range(len(segmID)):
        segms[segmID[i]].append(i)
        
    lcp = set(critsID_d)-set(critsID)  
    for i in range(len(lcp)):
        idx = list(critsID_d).index(list(lcp)[i])
        if critsType_d[idx]==0 or critsType_d[idx]==3:
            sortedRegion = segms[segmID[critsID_d[idx]]]
            saddles = list(edges_d[np.where(edges_d == idx)[0]][0])
            saddles.remove(idx)
            saddle = critsID_d[saddles[0]]
            sortedRegion.append(saddle)
            maxR = max(scalarOriginal[sortedRegion])
            minR = min(scalarOriginal[sortedRegion])
            if maxR-minR < PersThr:
                ub2[sortedRegion] = maxR
                lb2[sortedRegion] = minR
            else:
                snb = getNeighborOfSaddle3d(M, saddle, w, h, l, r)
                sr = list(sortedRegion)
                sortedRegion = list(set(sr+snb))
                sortedRegions = sorted(sortedRegion)
                scnt = r+1
                ub2, lb2 = splitRegion(sortedRegions, scnt, ub2, lb2,scalarOriginal, PersThr)
                        
                    
            ll[sortedRegion] = 1
    if len(lcp)==0:
        lcp2 = set(critsID)-set(critsID_d)
        for i in range(len(lcp2)):
            idx = list(critsID).index(list(lcp2)[i])
            if critsType[idx]==0 or critsType[idx]==3:
                sortedRegion = segms[segmID[critsID[idx]]]
                ub2[sortedRegion]=scalarOriginal[sortedRegion]
                lb2[sortedRegion]=scalarOriginal[sortedRegion]
    #plotM(ll.reshape(h,w))
    saveToDatFloat32(ub2, os.path.join(outDir, 'UpperErr2.dat'))
    saveToDatFloat32(lb2, os.path.join(outDir, 'LowerErr2.dat'))
    return ub2, lb2


def splitRegion(sortedRegions, scnt, ub2, lb2,scalarOriginal, PersThr):
    slen = int(len(sortedRegions)/scnt)
    if slen>0:
        srs = []
        for step in range(scnt):
            if step < scnt-1:
                sr = sortedRegions[step*slen: (step+1)*slen]
            else:
                sr = sortedRegions[step*slen:len(sortedRegions)]
            srs.append(sr)
        for sr in srs:
            maxR = max(scalarOriginal[sr])
            minR = min(scalarOriginal[sr])
            if maxR-minR < PersThr:
                ub2[sr] = maxR
                lb2[sr] = minR
            else:
                ub2, lb2 = splitRegion(sr, scnt, ub2, lb2,scalarOriginal, PersThr)
    else:
        for k in range(len(sortedRegions)):
            ub2[sortedRegions[k]] = scalarOriginal[sortedRegions[k]]
            lb2[sortedRegions[k]] = scalarOriginal[sortedRegions[k]]
    return ub2, lb2
    

def calculateErrBoundV2(segmID, scalarOriginal, globalErr, errs, critsID, critsID_d, critsType_d, edges_d, w, h, r):
    M = np.array(list(range(w*h))).reshape(h,w)
    errs2 = errs.copy()
    scnt = len(set(segmID))
    segms = []
    for i in range(scnt):
        segms.append([])
    for i in range(len(segmID)):
        segms[segmID[i]].append(i)

    cnt = 0
    l = set(critsID_d)-set(critsID)
    for i in range(len(l)):
        idx = list(critsID_d).index(list(l)[i])
        if critsType_d[idx]==0 or critsType_d[idx]==3:
            cnt += 1
            sortedRegion = segms[segmID[critsID_d[idx]]]
            saddles = list(edges_d[np.where(edges_d == idx)[0]][0])
            saddles.remove(idx)
            saddle = critsID_d[saddles[0]]
            snb = getNeighborOfSaddle(M, saddle, w, h,r)
            sr = list(sortedRegion)
            sortedRegion = np.array(list(set(sr+snb)))
            #plotSortedRegion(sortedRegion, w, h)
            errs2 = ErrorBoundFromSortedRegion(errs2, sortedRegion, scalarOriginal, globalErr)
    return errs2

def getNeighborOfSaddle(M, saddle, w, h, r):
    pos = (np.where(M==saddle))
    xx = pos[0][0]
    yy = pos[1][0]

    nb = [saddle]
    for i in range(xx-r, xx+r+1):
        for j in range(yy-r, yy+r+1):
            if i >=0 and i<h and j>=0 and j<w:
                nb.append(M[i,j])
    return nb

def getNeighborOfSaddle3d(M, saddle, w, h, l, r):
    pos = (np.where(M==saddle))
    xx = pos[0][0]
    yy = pos[1][0]
    zz = pos[2][0]
    nb = []
    for i in range(xx-r, xx+r+1):
        for j in range(yy-r, yy+r+1):
            for k in range(zz-r, zz+r+1):
                if i >=0 and i<l and j>=0 and j<w and k>=0 and k<h:
                    nb.append(M[i,j,k])
    return nb

def get3DPosOfSaddle(M,saddle):
    pos = (np.where(M==saddle))
    xx = pos[0][0]
    yy = pos[1][0]
    zz = pos[2][0]
    return [xx,yy,zz]

def find3DRegion(M,sr):
    rg = []
    for i in range(len(sr)):
        pos = (np.where(M==sr[i]))
        xx = pos[0][0]
        yy = pos[1][0]
        zz = pos[2][0]
        rg.append([xx,yy,zz])
    return np.array(rg)
        
def ErrorBoundFromSortedRegion(errs, sr, scalarOriginal,  globalErr):
    segmSF = scalarOriginal[sr]
    sortSF = sorted(segmSF)
    idx = sorted(range(len(segmSF)), key=lambda k: segmSF[k])
    for j in range(len(idx)):
        if j == 0:
            err = 0
        elif j == len(idx)-1:
            err = 0
        else:
            err = min((sortSF[j+1] - sortSF[j]-PERT)/2, (sortSF[j] - sortSF[j-1]-PERT)/2)
        if err < 0:
            err = 0
        if err>globalErr:
            err = globalErr
        errs[sr[idx[j]]]=err
    return errs
