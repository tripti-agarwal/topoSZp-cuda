from vtk_util import *
from plot_util import *
import gudhi

def checkFP(critsID, critsID_d, critsType, critsType_d):
    print ("\n\n\n\n Checking false positive...")
    flag = 0
    FPcnt = 0
    FNcnt = 0
    FTcnt = 0
    
    ind_dict1 = dict((k,i) for i,k in enumerate(critsID))
    ind_dict2 = dict((k,i) for i,k in enumerate(critsID_d))
    
    l = set(ind_dict2)-set(ind_dict1)
    idx2 = [ ind_dict2[x] for x in l]
    cT = critsType_d[idx2]
    cT1 = cT[cT==0]
    cT2 = cT[cT==3]
    FPcnt = len(cT1)+len(cT2)
 
    l = set(ind_dict1)-set(ind_dict2)
    idx1 = [ ind_dict1[x] for x in l]
    cT = critsType[idx1]
    cT1 = cT[cT==0]
    cT2 = cT[cT==3]
    FNcnt = len(cT1)+len(cT2)

    FTcnt = 0
    inter = set(ind_dict1).intersection(set(ind_dict2))
    for i in range(len(inter)):
        idx1 = list(critsID).index(list(inter)[i])
        idx2 = list(critsID_d).index(list(inter)[i])
        if critsType[idx1] != critsType_d[idx2]:
            if critsType[idx1] in [0,3] or critsType_d[idx2] in [0,3]:
                FTcnt += 1
    """
    idx1 = [ ind_dict1[x] for x in inter ]
    idx2 = [ ind_dict2[x] for x in inter ]  
    cT = critsType[idx1]-critsType_d[idx2]
    cT1 = cT[cT==2]
    cT2 = cT[cT==-2]
    FTcnt = len(cT1)+len(cT2)
    """
    print ("# False positive: " + str(FPcnt))
    print ("# False negative: " + str(FNcnt))
    print ("# False type: " + str(FTcnt))
    print ("\n\n\n\n")
    if FPcnt>0 or FNcnt>0:
        flag = 1
    return flag, [FPcnt, FNcnt, FTcnt]


def calculateCTforChecking(outDir, inputFileName, PersThr, scalarField):
    cmd = 'pvpython ./src/pvComputeMT.py ' + os.path.join(outDir, inputFileName) + ' ' + inputFileName.split('.')[0]+'_decompressed' + ' ' + outDir + '/ ' +str(PersThr) + ' ' + scalarField + ' ct'
    os.system(cmd)    
    critsFile = os.path.join(outDir, "crits_" + inputFileName.split('.')[0]+ '_decompressed' + '.vtk')
    vtuFile = os.path.join(outDir, "segms_" + inputFileName.split('.')[0] + '_decompressed.vtk')
    edgesFile = os.path.join(outDir, "edges_" + inputFileName.split('.')[0] + '_decompressed.vtk')
    critsID, critsType, nodesID = readCritsData(critsFile)
    segmID = readSegmData(vtuFile)
    edges = readEdgesData(edgesFile)
    return critsID, critsType, segmID, edges

def calculateCTforCheckingForTopoCompressor(inputFile, scalarField, PersThr, outDir):
    inputFileName = 'PersThr_' + str(PersThr) + '_' +scalarField
    cmd = 'pvpython ./src/pvComputeMT.py ' + inputFile + ' ' + inputFileName+'_decompressed' + ' ' + outDir + '/ ' +str(PersThr) + ' ' + scalarField + ' ct'
    os.system(cmd)
    critsFile = os.path.join(outDir, "crits_" + inputFileName + '_decompressed' + '.vtk')
    vtuFile = os.path.join(outDir, "segms_" + inputFileName + '_decompressed.vtk')
    edgesFile = os.path.join(outDir, "edges_" + inputFileName + '_decompressed.vtk')
    critsID, critsType, nodesID = readCritsData(critsFile)
    segmID = readSegmData(vtuFile)
    edges = readEdgesData(edgesFile)
    return critsID, critsType, segmID, edges
    

def checkPerformanceOfSZ(inputDir, inputFileName,  w, h, folder):
    workingDir = os.path.join(inputDir, folder)
    tdaDir =  os.path.join(workingDir, 'TDA')
    make_dir(tdaDir)
    outSF =  os.path.join(inputDir, 'sf.dat')
    sf = np.fromfile(outSF, dtype='float32')
    
    outSF =  os.path.join(workingDir, 'sf.dat.cmp.out')
    sf_d = np.fromfile(outSF, dtype='float32')

    inputFileDir = os.path.join(inputDir, inputFileName)
    vtkType = inputFileDir.split('.')[-1]
    if vtkType == 'vti':
        reader = vtk.vtkXMLImageDataReader()
    elif vtkType == 'vtp':
        reader = vtk.vtkXMLPolyDataReader()
    else:
        reader = vtk.vtkXMLUnstructuredGridReader()
    reader.SetFileName(inputFileDir) 
    reader.Update()

    saveDecompressedToFile(sf, [sf_d], os.path.join(tdaDir, inputFileName), reader, vtkType, [''])

    critsID, critsType, segmID, edges = calculateCTforChecking(tdaDir, inputFileName, 0.12, 'velocityMagnitude-original')
    critsID_d, critsType_d, segmID_d, edges_d = calculateCTforChecking(tdaDir, inputFileName, 0.12, 'velocityMagnitude-Decompressed')
    flag, Fcnt = checkFP(critsID, critsID_d, critsType, critsType_d)
    return Fcnt

def checkPerformanceOfTopoCompressor(inputDir, inputFileName, globalDir, PersThr, scalarField):
    tdaDir =  os.path.join(globalDir, 'TDA')
    make_dir(tdaDir)
    critsID, critsType, segmID, edges = calculateCTforCheckingForTopoCompressor(os.path.join(inputDir, inputFileName), scalarField, PersThr, tdaDir)
    critsID_d, critsType_d, segmID_d, edges_d = calculateCTforCheckingForTopoCompressor(os.path.join(globalDir, 'PersThr_' + str(PersThr) + '_decompressed.vti'), 'Decompressed', PersThr, tdaDir)
    flag, Fcnt = checkFP(critsID, critsID_d, critsType, critsType_d)
    return Fcnt

def savePDDist(TopoCompDir, PDo, PersThrs, globalErrs):
    for globalErr in globalErrs:
        gTopoCompDir = os.path.join(TopoCompDir, 'GlobalErr_' + str(globalErr))
        wDistFile = os.path.join(gTopoCompDir, 'wDist.txt')
        bDistFile = os.path.join(gTopoCompDir, 'bDist.txt')
        wDists = []
        bDists = []
        for PersThr in PersThrs:
            print (globalErr, PersThr)
            pTopoCompDir = os.path.join(gTopoCompDir, 'PersThr_' + str(PersThr))
            PDTopoComp = getPDFileDir(pTopoCompDir)
            print(PDTopoComp)
            print (PDo)
            cmd = ['wasserstein_dist', PDo, PDTopoComp, '2']
            wdist = float(subprocess.Popen( cmd, stdout=subprocess.PIPE ).communicate()[0])

            """
            cmd = ['bottleneck_dist', PDo, PDTopoComp]
            bdist = float(subprocess.Popen( cmd, stdout=subprocess.PIPE ).communicate()[0])
            """
            pd1=np.loadtxt(PDTopoComp)
            pd2=np.loadtxt(PDo)
            bdist = gudhi.bottleneck_distance(pd1, pd2)
            
            wDists.append(wdist)
            bDists.append(bdist)
        np.savetxt(wDistFile, np.array(wDists), fmt="%.6f")
        np.savetxt(bDistFile, np.array(bDists), fmt="%.6f")
    
def comparisonWithCmpViaDist(inputDir, PersThrs, globalErrs):
    PDo = getPDFileDir(inputDir)
    #savePDDist(os.path.join(inputDir, 'eb'), PDo, PersThrs, globalErrs)
    savePDDist(os.path.join(inputDir, 'lbub'), PDo, PersThrs, globalErrs)
    savePDDist(os.path.join(inputDir, 'TopoQz'), PDo, PersThrs, globalErrs)
    plotLineChartForPDDist(inputDir, PersThrs, globalErrs)
    
            
            
