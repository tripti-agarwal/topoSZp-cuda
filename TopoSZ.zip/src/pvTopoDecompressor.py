#!/usr/bin/env pvpython

import sys
import math
import vtk
from vtk.util.numpy_support import vtk_to_numpy
import os
from paraview.simple import *

inputDir = sys.argv[1]
outputDir = sys.argv[2]

inputData = TTKTopologicalCompressionReader(FileName=inputDir)
SaveData(outputDir, proxy=inputData)
