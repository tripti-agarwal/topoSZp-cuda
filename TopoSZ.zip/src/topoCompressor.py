from functions_util import *

from vtk_util import *
from plot_util import *
from errorBound_util import *
from tda_util import *
from compressors_util import *

def getInitialContourTree(inputDir, inputFileName, szType, PersThr, globalErr, scalarField):
    inputFileDir = os.path.join(inputDir, inputFileName)
    topoSZDir = os.path.join(inputDir, szType)
    globalDir = os.path.join(topoSZDir, 'GlobalErr_' + str(globalErr))
    outDir = os.path.join(globalDir, 'PersThr_' + str(PersThr))
    make_dir(outDir)
    timeDir = os.path.join(outDir, 'time')
    make_dir(timeDir)
    cmd = 'pvpython ./src/pvComputeMT.py ' + inputFileDir + ' ' + inputFileName.split('.')[0] + ' ' + outDir + '/ ' +str(PersThr) + ' ' + scalarField + ' ct'
    os.system(cmd)
    return inputFileDir, outDir

def checkQuality(outDir,scalarOriginal, sf, tmpVTKfileName, reader, vtkType, PersThr):
    outSF2 =  os.path.join(outDir, 'sf2.dat.out')
    sf2 = np.fromfile(outSF2, dtype='float32')
    saveDecompressedToFile(scalarOriginal, [sf, sf2], os.path.join(outDir, tmpVTKfileName), reader, vtkType, ['-NoFNFT', '-NoFPFNFT'])
    critsID_d, critsType_d, segmID_d, edges_d = calculateCTforChecking(outDir, tmpVTKfileName, PersThr, 'velocityMagnitude-Decompressed-NoFPFNFT')
    return critsID_d, critsType_d, segmID_d, edges_d, sf2

def runTopoSZ(szType, outDir, loopID, segmID, segmID_d, scalarOriginal, globalErr, PersThr, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, errsX, ubX, lbX):
    errs = copy.deepcopy(errsX)
    ub = copy.deepcopy(ubX)
    lb = copy.deepcopy(lbX)
    if szType == 'eb':
        figFile = os.path.join(outDir, 'ErrBound_Iter'+str(loopID)+'.png')
        errs2 = np.array(calculateErrBoundV2(segmID_d, scalarOriginal, globalErr, errs, critsID, critsID_d, critsType_d, edges_d, w, h,  loopID))
        #plotErrBounds(errs.reshape(h, w), errs2.reshape(h, w), ['Error bound for Iteration '+ str(loopID-1), 'Error bound for Iteration '+ str(loopID)], figFile)
        ub2 = ub
        lb2 = lb
        runSZ(outDir, scalarOriginal, errs2, 2, w, h, szType)
    else:
        figFile = os.path.join(outDir, 'ublb'+str(loopID)+'.png')
        errs2 = errs
        if l == 0:
            #ub2, lb2 = calculate_eblb(outDir, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType_d, edges_d, w, h,  loopID, PersThr)
            #ub2, lb2 = calculate_eblb_new(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h,  loopID, PersThr)
            #ub2, lb2 = calculate_eblb_3d_new(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h, l, loopID, PersThr)
            ub2, lb2 = calculate_eblb_3d_new0(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, loopID, PersThr)
            plotErrBounds(lb2.reshape(h, w), ub2.reshape(h, w), ['Lower bound', 'Upper bound'], figFile)
            runSZ(outDir, scalarOriginal, errs2, 2, w, h, szType)
        else:
            #ub2, lb2 = calculate_eblb_3d(outDir, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h, l, loopID, PersThr)
            print ("\n\n\n")
            ub2, lb2 = calculate_eblb_3d_new0(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, loopID, PersThr)
            runSZ3D(outDir, scalarOriginal, errs2, 2, w, h, l, szType)
    return errs2, ub2, lb2

def runTopoSZ2(szType, outDir, loopID, segmID, segmID_d, scalarOriginal, globalErr, PersThr, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, errsX, ubX, lbX, lbda, rd, t4, t5):
    errs = copy.deepcopy(errsX)
    ub = copy.deepcopy(ubX)
    lb = copy.deepcopy(lbX)
    if szType == 'eb':
        figFile = os.path.join(outDir, 'ErrBound_Iter'+str(loopID)+'.png')
        ts = time.time()
        errs2 = np.array(calculateErrBoundV2(segmID_d, scalarOriginal, globalErr, errs, critsID, critsID_d, critsType_d, edges_d, w, h,  loopID))
        t4_ = time.time()-ts
        t4 = t4+t4_
        #plotErrBounds(errs.reshape(h, w), errs2.reshape(h, w), ['Error bound for Iteration '+ str(loopID-1), 'Error bound for Iteration '+ str(loopID)], figFile)
        ub2 = ub
        lb2 = lb
        ts = time.time()
        runSZ(outDir, scalarOriginal, errs2, 2, w, h, szType)
        t5_ = time.time()-ts
        t5 = t5+t5_
    else:
        figFile = os.path.join(outDir, 'ublb'+str(loopID)+'.png')
        errs2 = errs
        if l == 0:
            #ub2, lb2 = calculate_eblb(outDir, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType_d, edges_d, w, h,  loopID, PersThr)
            #ub2, lb2 = calculate_eblb_new(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h,  loopID, PersThr)
            #ub2, lb2 = calculate_eblb_3d_new(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h, l, loopID, PersThr)
            ts = time.time()
            ub2, lb2,rd = calculate_eblb_3d_new02(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, loopID, PersThr, lbda, rd)
            t4_ = time.time()-ts
            t4 = t4+t4_
            #plotErrBounds(lb2.reshape(h, w), ub2.reshape(h, w), ['Lower bound', 'Upper bound'], figFile)
            #plt.show()
            ts = time.time()
            runSZ(outDir, scalarOriginal, errs2, 2, w, h, szType)
            t5_ = time.time()-ts
            t5 = t5+t5_
        else:
            #ub2, lb2 = calculate_eblb_3d(outDir, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges_d, w, h, l, loopID, PersThr)
            print ("\n\n\n")
            ts = time.time()
            ub2, lb2, rd = calculate_eblb_3d_new02(outDir, segmID, segmID_d, scalarOriginal, globalErr, ub, lb, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, loopID, PersThr, lbda, rd)
            t4_ = time.time()-ts
            t4 = t4+t4_
            ts = time.time()
            runSZ3D(outDir, scalarOriginal, errs2, 2, w, h, l, szType)
            t5_ = time.time()-ts
            t5 = t5+t5_
    return errs2, ub2, lb2, t4, t5, rd

def calculateHomologyPreservingErrBound(inputDir, inputFileName,PersThr, globalErr, w, h, l,  szType, scalarField, pdmt, firstTime):
    inputFileDir, outDir = getInitialContourTree(inputDir, inputFileName, szType, PersThr, globalErr, scalarField)
    reader, vtkType = getOriginalStructural(inputFileDir)

    vtuFile = os.path.join(outDir, "segms_" + inputFileName.split('.')[0] + '.vtk')
    scalar, segmID = readSegmSFData(vtuFile, scalarField)
    critsFile = os.path.join(outDir, "crits_" + inputFileName.split('.')[0] + '.vtk')
    edgesFile = os.path.join(outDir, "edges_" + inputFileName.split('.')[0] + '.vtk')
    critsID, critsType, nodesID = readCritsData(critsFile)
    edges = readEdgesData(edgesFile)
    
    if szType == 'lbub':
        globalErr = globalErr/2
    
    scalarOriginal = readScalarFromVTI(inputFileDir, scalarField)
    errs, ub, lb = calculateErrBoundV1(segmID, scalarOriginal, globalErr, critsID, globalErr, outDir)
    if szType == 'lbub':
        if l == 0:
            errs = np.ones(w*h)*globalErr
            figFile = os.path.join(outDir, 'ublb0.png')
            plotErrBounds(lb.reshape(h, w), ub.reshape(h, w), ['Lower bound', 'Upper bound'], figFile)
        else:
            errs = np.ones(w*h*l)*globalErr
    print ("\n\n\n\n========No false negative or false type========")
    if l == 0:
        runSZ(outDir, scalarOriginal, errs, 1, w, h, szType)
    else:
        runSZ3D(outDir, scalarOriginal, errs, 1, w, h, l, szType)
    tmpVTKfileName = inputFileName
    outSF =  os.path.join(outDir, 'sf1.dat.out')
    sf = np.fromfile(outSF, dtype='float32')
    #plotM(sf.reshape((l,w,h))[0,:,:])
    saveDecompressedToFile(scalarOriginal, [sf], os.path.join(outDir, tmpVTKfileName), reader, vtkType, ['1'])

    sfAll = [sf]
    titleAll = ['-Iter0']

    print ("\n\n\n\n========No false positive, false negative, or false type========")
    loopID = 1
    critsID_d, critsType_d, segmID_d, edges_d = calculateCTforChecking(outDir, tmpVTKfileName, PersThr, "velocityMagnitude" + '-Decompressed1')
    errs2, ub2, lb2 = runTopoSZ(szType, outDir, loopID, segmID, segmID_d, scalarOriginal, globalErr, PersThr, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, errs, ub, lb)
    
    critsID_d, critsType_d, segmID_d, edges_d, sf2 = checkQuality(outDir,scalarOriginal, sf, tmpVTKfileName, reader, vtkType, PersThr)
    #plotM(sf2.reshape((l,w,h))[-1,:,:])
    sfAll.append(sf2)
    titleAll.append('-Iter'+str(loopID))
    flag, Fcnt = checkFP(critsID, critsID_d, critsType, critsType_d)
    
    while flag==1 and loopID<20:
        loopID += 1
        print ("\n\n\n" + str(loopID)+"\n\n\n\n")
        errs2, ub2, lb2 = runTopoSZ(szType, outDir, loopID, segmID, segmID_d, scalarOriginal, globalErr, PersThr, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, errs2, ub2, lb2)
        critsID_d, critsType_d, segmID_d, edges_d, sf2 = checkQuality(outDir,scalarOriginal, sf, tmpVTKfileName, reader, vtkType, PersThr)
        sfAll.append(sf2)
        titleAll.append('-Iter'+str(loopID))
        flag, Fcnt = checkFP(critsID, critsID_d, critsType, critsType_d)
    
    saveDecompressedToFile(scalarOriginal, sfAll, os.path.join(outDir, 'IterAll.'+vtkType), reader, vtkType, titleAll)
    gErr = max(abs(sf2 - scalarOriginal))
    psnr = calculatePSNR(scalarOriginal, sf2)

    if pdmt:
        savePersistenceDiagramAndMergeTree(outDir, 'IterAll.'+vtkType, 'velocityMagnitude-Decompressed-Iter'+str(loopID))
        if firstTime:
            savePersistenceDiagramAndMergeTree(outDir, tmpVTKfileName, 'velocityMagnitude-original', inputDir)
        
    if flag == 0:
        return "Succeed", loopID, gErr, Fcnt, psnr
    else:
        return "Fail", loopID, gErr, Fcnt, psnr
    
        
def calculateHomologyPreservingErrBound2(inputDir, inputFileName,PersThr, globalErr, w, h, l,  szType, scalarField, pdmt, firstTime, lbda):
    _t1 = 0
    _t2 = 0
    _t3 = 0
    _t4 = 0
    _t5 = 0
    _t6 = 0
    ts = time.time()
    inputFileDir, outDir = getInitialContourTree(inputDir, inputFileName, szType, PersThr, globalErr, scalarField)
    t1 = time.time()-ts
    _t1 = time.time()-ts
    reader, vtkType = getOriginalStructural(inputFileDir)
    timeDir = os.path.join(outDir, 'time')
    #t1,t2,t3 = np.loadtxt(os.path.join(timeDir, 'ctTime.txt'))

  
    vtuFile = os.path.join(outDir, "segms_" + inputFileName.split('.')[0] + '.vtk')
    scalar, segmID = readSegmSFData(vtuFile, scalarField)
    critsFile = os.path.join(outDir, "crits_" + inputFileName.split('.')[0] + '.vtk')
    edgesFile = os.path.join(outDir, "edges_" + inputFileName.split('.')[0] + '.vtk')
    critsID, critsType, nodesID = readCritsData(critsFile)
    edges = readEdgesData(edgesFile)
    
    if szType == 'lbub':
        globalErr = globalErr/2
    
    scalarOriginal = readScalarFromVTI(inputFileDir, scalarField)
    ub, lb, t4 = calculateErrBoundUbLB(segmID, scalarOriginal, globalErr, critsID, globalErr, outDir)
    if szType == 'lbub':
        if l == 0:
            errs = np.ones(w*h)*globalErr
            #figFile = os.path.join(outDir, 'ublb0.png')
            #plotErrBounds(lb.reshape(h, w), ub.reshape(h, w), ['Lower bound', 'Upper bound'], figFile)
        else:
            errs = np.ones(w*h*l)*globalErr
    print ("\n\n\n\n========No false negative or false type========")
    _t2 = _t2+ t4
    ts = time.time()
    if l == 0:
        runSZ(outDir, scalarOriginal, errs, 1, w, h, szType)
    else:
        runSZ3D(outDir, scalarOriginal, errs, 1, w, h, l, szType)
    t5 = time.time()-ts
    _t3 = time.time()-ts
    tmpVTKfileName = inputFileName
    outSF =  os.path.join(outDir, 'sf1.dat.out')
    sf = np.fromfile(outSF, dtype='float32')
    saveDecompressedToFile(scalarOriginal, [sf], os.path.join(outDir, tmpVTKfileName), reader, vtkType, ['1'])

    sfAll = [sf]
    titleAll = ['-Iter0']
   

    print ("\n\n\n\n========No false positive, false negative, or false type========")
    loopID = 0
    rd = 1
    ts = time.time()
    critsID_d, critsType_d, segmID_d, edges_d = calculateCTforChecking(outDir, tmpVTKfileName, PersThr, "velocityMagnitude" + '-Decompressed1')
    t1_ = time.time()-ts
    t1 = t1+t1_
    _t1 = _t1+t1_
    #t1, t2, t3 = updateCTTime(t1, t2, t3, timeDir)
    flag, Fcnt = checkFP(critsID, critsID_d, critsType, critsType_d)
    
    if flag == 1:
        loopID = 1
        errs2, ub2, lb2, t4, t5, rd = runTopoSZ2(szType, outDir, loopID, segmID, segmID_d, scalarOriginal, globalErr, PersThr, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, errs, ub, lb,lbda, rd, t4, t5)
        ts = time.time()
        critsID_d, critsType_d, segmID_d, edges_d, sf2 = checkQuality(outDir,scalarOriginal, sf, tmpVTKfileName, reader, vtkType, PersThr)
        #t1, t2, t3 = updateCTTime(t1, t2, t3, timeDir)
        t1_ = time.time()-ts
        t1 = t1+t1_
        flag, Fcnt = checkFP(critsID, critsID_d, critsType, critsType_d)
        sfAll.append(sf2)
        titleAll.append('-Iter'+str(loopID))
    else:
        sf2 = sf

    print ("\n\n\n time1")
    print (t1)
        
    
    while flag==1 and loopID<20:
        loopID += 1
        print ("\n\n\n" + str(loopID)+"\n\n\n\n")
        errs2, ub2, lb2, t4, t5, rd = runTopoSZ2(szType, outDir, loopID, segmID, segmID_d, scalarOriginal, globalErr, PersThr, critsID, critsID_d, critsType, critsType_d, edges, edges_d, w, h, l, errs2, ub2, lb2, lbda, rd, t4, t5)
        ts = time.time()
        print ("\n\n\n time4,5")
        print (t4, t5)
        critsID_d, critsType_d, segmID_d, edges_d, sf2 = checkQuality(outDir,scalarOriginal, sf, tmpVTKfileName, reader, vtkType, PersThr)
        t1_ = time.time()-ts
        print ("\n\n\n time1")
        print (t1_)
        t1 = t1+t1_
        #t1, t2, t3 = updateCTTime(t1, t2, t3, timeDir)
        sfAll.append(sf2)
        titleAll.append('-Iter'+str(loopID))
        flag, Fcnt = checkFP(critsID, critsID_d, critsType, critsType_d)
    
    saveDecompressedToFile(scalarOriginal, sfAll, os.path.join(outDir, 'IterAll.'+vtkType), reader, vtkType, titleAll)
    gErr = max(abs(sf2 - scalarOriginal))
    psnr = calculatePSNR(scalarOriginal, sf2)
    if loopID==0:
        rto = np.fromfile( os.path.join(outDir, 'sf1.dat_ratio.out'), dtype='float32')[0]
        timeInfo = [_t1, _t2, _t3, 0, 0, 0]
    else:
        rto = np.fromfile( os.path.join(outDir, 'sf2.dat_ratio.out'), dtype='float32')[0]
        _t4 = t1-_t1
        _t5 = t4-_t2
        _t6 = t5-_t3
        timeInfo = [_t1, _t2, _t3, _t4, _t5, _t6]

    if pdmt:
        savePersistenceDiagramAndMergeTree(outDir, 'IterAll.'+vtkType, 'velocityMagnitude-Decompressed'+titleAll[-1])
        #savePersistenceDiagramAndMergeTree(outDir, tmpVTKfileName, 'velocityMagnitude-Decompressed-NoFPFNFT')
        if firstTime:
            savePersistenceDiagramAndMergeTree(outDir, 'IterAll.'+vtkType, 'velocityMagnitude-original', inputDir)
            
    #tTotal = t1+t4+t5
    #runningTime = np.array([[t1,t4,t5],[t1/tTotal*100,t4/tTotal*100,t5/tTotal*100]])
    writeTimeFile(os.path.join(timeDir, 'TopoSZTime.txt'),[t1,t4,t5], loopID )
    writeTimeFile2(os.path.join(timeDir, 'TopoSZTime2.txt'),timeInfo, loopID )
    if flag == 0:
        return "Succeed", loopID, gErr, Fcnt, psnr, rto
    else:
        return "Fail", loopID, gErr, Fcnt, psnr,rto

