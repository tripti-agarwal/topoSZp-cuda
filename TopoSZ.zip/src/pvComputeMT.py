#!/usr/bin/env pvpython

import sys
import math
import vtk
import numpy as np
from vtk.util.numpy_support import vtk_to_numpy
import os
from paraview.simple import *
import time

inputDir = sys.argv[1]
fileName = sys.argv[2]
outputDir = sys.argv[3]
PersThr = float(sys.argv[4])
scalarField = sys.argv[5]
treeType = sys.argv[6]

timeDir = os.path.join(outputDir, 'time')

inputFileName = inputDir
fileType = inputDir.split('.')[-1]
outputCritsFileName = outputDir + "crits_" + fileName + '.vtk'
outputEdgesFileName = outputDir + "edges_" + fileName + '.vtk'
outputSegmsFileName = outputDir + "segms_" + fileName + '.vtk'

if fileType == 'vtp':
    inputData = XMLPolyDataReader(FileName=[inputFileName])
    processedData = Tetrahedralize(inputData)
if fileType == 'vti':
    inputData = XMLImageDataReader(FileName=[inputFileName])
    processedData = inputData

#ts = time.time()
persistenceDiagram = TTKPersistenceDiagram(processedData)
persistenceDiagram.ScalarField = scalarField

#t1 = time.time()-ts

#ts = time.time()
criticalPointPairs = Threshold(persistenceDiagram)
criticalPointPairs.Scalars = ['CELLS', 'PairIdentifier']
criticalPointPairs.LowerThreshold = -0.1
criticalPointPairs.UpperThreshold = 9999999999999

persistentPairs = Threshold(criticalPointPairs)
persistentPairs.Scalars = ['CELLS', 'Persistence']

print ("Persistence Simplification...")
print (time.time())
print ('Threshold: ' + str(PersThr))
persistentPairs.LowerThreshold = PersThr
persistentPairs.UpperThreshold = 9999999999999
topologicalSimplification = TTKTopologicalSimplification(
    Domain=processedData, Constraints=persistentPairs, ScalarField = scalarField)
print ("Persistence Simplification...End")
print (time.time())
#t2 = time.time()-ts

#ts = time.time()
ftm = TTKMergeandContourTreeFTM(topologicalSimplification)
ftm.ScalarField = scalarField
if treeType == 'mt':
    ftm.TreeType = 0
elif treeType == 'st':
    ftm.TreeType = 'Split Tree'
else:
    ftm.TreeType = 'Contour Tree'
#t3 = time.time()-ts

SaveData(outputCritsFileName, OutputPort(ftm, 0), FileType='Ascii')
SaveData(outputEdgesFileName, OutputPort(ftm, 1), FileType='Ascii')
SaveData(outputSegmsFileName, OutputPort(ftm, 2))

timeFile = os.path.join(timeDir, 'ctTime.txt')
#np.savetxt(timeFile, np.array([t1, t2, t3]))
