#!/usr/bin/env pvpython

import sys
import math
import vtk
from vtk.util.numpy_support import vtk_to_numpy
import os
from paraview.simple import *

inputDir = sys.argv[1]
fileName = sys.argv[2]
scalarField = sys.argv[3]
outputDir = inputDir

inputFileName = os.path.join(inputDir,fileName)
fileType = fileName.split('.')[-1]

outputEdgesJTFileName = outputDir + "edgesJT_" + fileName.split('.')[0] + '.vtk'
outputEdgesSTFileName = outputDir + "edgesST_" + fileName.split('.')[0] + '.vtk'
outputPDFileName = outputDir + "PD_" + fileName.split('.')[0] + '.vtu'

if fileType == 'vtp':
    inputData = XMLPolyDataReader(FileName=[inputFileName])
    processedData = Tetrahedralize(inputData)
if fileType == 'vti':
    inputData = XMLImageDataReader(FileName=[inputFileName])
    processedData = inputData
    

persistenceDiagram = TTKPersistenceDiagram(processedData)
persistenceDiagram.ScalarField = scalarField

SaveData(outputPDFileName, proxy=persistenceDiagram)



ftm = TTKMergeandContourTreeFTM(processedData)
ftm.ScalarField = scalarField
ftm.TreeType = 0
SaveData(outputEdgesJTFileName, OutputPort(ftm, 1), FileType='Ascii')

ftm = TTKMergeandContourTreeFTM(processedData)
ftm.ScalarField = scalarField
ftm.TreeType = 'Split Tree'
SaveData(outputEdgesSTFileName, OutputPort(ftm, 1), FileType='Ascii')
