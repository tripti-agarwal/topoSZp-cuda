from functions_util import *
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.pyplot as plt

def plotM(M):
    fig = plt.figure(frameon=False)
    im2 = plt.imshow(M, cmap=plt.cm.viridis, alpha=.9, origin='lower')
    plt.show()

def plotErrBounds(M1, M2, titles, figFile):
    minv = min(np.min(M1), np.min(M2))
    maxv = max(np.max(M1), np.max(M2))
    w, h = M1.shape
    perc = w/h
    if w > h:
        ww = 8
        hh = int(5*perc/1.5)
    else:
        ww = 20
        hh = int(15*perc/1.5)
    fig = plt.figure(figsize=(ww, hh))
    ax1 = plt.subplot(1, 2, 1)
    plt.imshow(M1, vmin=minv, vmax=maxv, cmap=plt.cm.viridis, alpha=.9, origin='lower')
    plt.axis('off')
    ax1.set_title(titles[0])
    ax2 = plt.subplot(1, 2, 2)
    im = plt.imshow(M2, vmin=minv, vmax=maxv, cmap=plt.cm.viridis, alpha=.9, origin='lower')
    ax2.set_title(titles[1])
    plt.axis('off')
    divider = make_axes_locatable(ax2)
    cax = divider.append_axes("right", size="2%", pad=0.25)
    plt.colorbar(im, cax=cax)
    #plt.show()
    plt.savefig(figFile)

def plotLineChart(inputDir, inputFileName, PersThrs, globalErr):
    ratio1_overall = []
    ratio2_overall = []
    ratio1_data = []
    ratio2_data = []
    globalDir = os.path.join(inputDir, 'GlobalErr_' + str(globalErr))
    for PersThr in PersThrs:
        outDir = os.path.join(globalDir, 'PersThr_' + str(PersThr))
        ratio1 = np.fromfile( os.path.join(outDir, 'sf1.dat_ratio.out'), dtype='float32')
        ratio2 = np.fromfile( os.path.join(outDir, 'sf2.dat_ratio.out'), dtype='float32')
        ratio1_overall.append(ratio1[0])
        ratio2_overall.append(ratio2[0])
        ratio1_data.append(ratio1[1])
        ratio2_data.append(ratio2[1])

    fig = plt.figure(figsize=(12, 4))
    plt.plot( PersThrs,ratio1_overall, linewidth=1, label='No false negative or false type')
    plt.plot( PersThrs,ratio2_overall, linewidth=1, label='No false positive, false negative, or false type')
    plt.grid(color='gray', linestyle='-', linewidth=0.1)
    plt.title("Overall compressed ratio w.r.t. persistence simplification (global error: "+str(globalErr) + ")")
    plt.xlabel("Persistence simplification")
    plt.ylabel("Overall compressed ratio")
    plt.legend()
    plt.savefig(os.path.join(inputDir, 'overallCompressed_'+str(globalErr)+'.png'))
    return ratio2_overall

def plotLineChartForSZ(ratios, Fcnts, globalErrs, figFile):
    fig = plt.figure(figsize=(12, 4))
    ax = fig.add_subplot(1, 2, 1)
    plt.plot( globalErrs,Fcnts[:, 0], linewidth=1, label='False Positive (FP)')
    plt.plot( globalErrs,Fcnts[:, 1], linewidth=1, label='False Negtaive (FN)')
    plt.plot( globalErrs,Fcnts[:, 2], linewidth=1, label='False Type (FT)')
    plt.grid(color='gray', linestyle='-', linewidth=0.1)
    plt.title("Occurrence of FP, FN, FT w.r.t. Global Error")
    plt.xlabel("Global error")
    plt.ylabel("#")
    ax.set_yscale('symlog')
    ax.set_xscale('log')
    plt.legend()
    
    ax = fig.add_subplot(1, 2, 2)
    plt.plot( globalErrs,ratios, linewidth=1)
    plt.grid(color='gray', linestyle='-', linewidth=0.1)
    plt.title("Compression ratio w.r.t. Global Error")
    plt.xlabel("Global error")
    plt.ylabel("Overall compressed ratio")
    #ax.set_yscale('log')
    ax.set_xscale('log')
    #plt.show()
    plt.savefig(figFile)

def plotLineChartforOtherCmps(inputDir, cmps, globalErrs):
    fig = plt.figure(figsize=(10, 4))
    ax = fig.add_subplot(1, 1, 1)
    colors = ['darkorange', "seagreen", "dodgerblue"]
    linestyles = ['-', "--", ":"]
    
    for i in range(len(cmps)):
        cmpr = cmps[i]
        cmpDir = os.path.join(inputDir, cmpr)
        FcntFile = os.path.join(cmpDir, 'FPFNFT.txt')
        Fcnts = np.loadtxt(FcntFile)
        globalErrsN = globalErrs.copy()
        if cmpr == "FPZIP":
            gErrFile = os.path.join(cmpDir, 'gErrs.txt')
            globalErrsN = np.loadtxt(gErrFile).tolist()
        else:
            globalErrsN = globalErrs.copy()
        FcntSum = np.sum(Fcnts,axis=1)
        plt.plot( globalErrsN[1:],FcntSum[1:], ls = linestyles[0], c=colors[i], linewidth=2, label=cmpr)
        #plt.plot( globalErrsN,Fcnts[:, 1], ls = linestyles[1], c=colors[i], linewidth=2)
        #plt.plot( globalErrsN,Fcnts[:, 2], ls = linestyles[2], c=colors[i], linewidth=2)
    
    """
    dummy_lines = []
    for i in range(3):
        dummy_lines.append(ax.plot([],[], c="black", ls = linestyles[i])[0])
    lines = ax.get_lines()
    legend1 = plt.legend([lines[i] for i in [0,3,6]], [cmps[0], cmps[1], cmps[2]], loc=0)
    legend2 = plt.legend([dummy_lines[i] for i in [0,1,2]], ["False Positive (FP)", "False Negtaive (FN)", 'False Type (FT)'], loc=4)
    ax.add_artist(legend1)
    """
    plt.legend()
    plt.grid(color='gray', linestyle='--', linewidth=0.2)
    #plt.title("")
    plt.xlabel("Global error bound")
    plt.ylabel("Occurrence of faulty cases")
    ax.set_yscale('symlog')
    ax.set_xscale('log')
    plt.show()

    for i in range(len(cmps)):
        cmpr = cmps[i]
        cmpDir = os.path.join(inputDir, cmpr)
        ratioFile = os.path.join(cmpDir, 'compressionRatio.txt')
        ratios = np.loadtxt(ratioFile)
        ax = fig.add_subplot(1, 2, 2)
        plt.plot( globalErrs,ratios, c=colors[i], linewidth=2, label=cmpr)
    plt.legend()
    plt.grid(color='gray', linestyle='--', linewidth=0.2)
    #plt.title("Compression ratio w.r.t. Global Error")
    plt.xlabel("Global error")
    plt.ylabel("Overall compressed ratio")
    #ax.set_yscale('log')
    ax.set_xscale('log')
    plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
    plt.show()
    
        

def plotLineChartForPDDist(inputDir, PersThrs, globalErrs):
    lwid = 2
    for globalErr in globalErrs:
        #bDist1, wDist1 = readPDDistFile(inputDir, 'eb', globalErr)
        bDist2, wDist2 = readPDDistFile(inputDir, 'lbub', globalErr)
        bDist3, wDist3 = readPDDistFile(inputDir, 'TopoQz', globalErr)

        TopoCompDir = os.path.join(inputDir, 'lbub')
        gTopoCompDir = os.path.join(TopoCompDir, 'GlobalErr_' + str(globalErr)) 
        ratios1, Fcnts1, PSNRs1, gErrs1 = readCmpInfo(gTopoCompDir)
        TopoCompDir = os.path.join(inputDir, 'TopoQz')
        gTopoCompDir = os.path.join(TopoCompDir, 'GlobalErr_' + str(globalErr)) 
        ratios2, Fcnts2, PSNRs2, gErrs2 = readCmpInfo(gTopoCompDir)
        
        figDir = os.path.join(inputDir, 'Figs')
        make_dir(figDir)
        figFile = os.path.join(figDir, 'PDDist_'+ 'GlobalErr_' + str(globalErr)+'.png')
        
        fig = plt.figure(figsize=(10, 6))
        ax = fig.add_subplot(2, 2, 1)
        #plt.plot(PersThrs, bDist1, linewidth=lwid, label='TopoSZ-eb')
        plt.plot(PersThrs, bDist2, linewidth=lwid, label='TopoSZ-ublb')
        plt.plot(PersThrs, bDist3, linewidth=lwid, label='TopoQz')
        plt.title("Bottleneck distance")
        plt.grid(color='gray', linestyle='-', linewidth=0.1)
        plt.xlabel("Persistence threshold")
        plt.legend()

        ax = fig.add_subplot(2, 2, 2)
        #plt.plot(PersThrs, wDist1, linewidth=lwid, label='TopoSZ-eb')
        plt.plot(PersThrs, wDist2, linewidth=lwid, label='TopoSZ-ublb')
        plt.plot(PersThrs, wDist3, linewidth=lwid, label='TopoQz')
        plt.title("Wasserstein distance (p=2)")
        plt.grid(color='gray', linestyle='-', linewidth=0.1)
        plt.xlabel("Persistence threshold")
        #plt.ylabel("PSNR")
        plt.legend()

        ax = fig.add_subplot(2, 2, 3)
        #plt.plot(PersThrs, wDist1, linewidth=lwid, label='TopoSZ-eb')
        plt.plot(PersThrs, PSNRs1, linewidth=lwid, label='TopoSZ-ublb')
        plt.plot(PersThrs, PSNRs2, linewidth=lwid, label='TopoQz')
        plt.title("PSNR")
        plt.grid(color='gray', linestyle='-', linewidth=0.1)
        plt.xlabel("Persistence threshold")
        plt.ylabel("PSNR")
        plt.legend()

        ax = fig.add_subplot(2, 2, 4)
        #plt.plot(PersThrs, wDist1, linewidth=lwid, label='TopoSZ-eb')
        plt.plot(PersThrs, ratios1, linewidth=lwid, label='TopoSZ-ublb')
        plt.plot(PersThrs, ratios2, linewidth=lwid, label='TopoQz')
        plt.title("Compression ratio")
        plt.grid(color='gray', linestyle='-', linewidth=0.1)
        plt.xlabel("Persistence threshold")
        #plt.ylabel("PSNR")
        plt.legend()

        plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
        #plt.show()
        plt.savefig(figFile)

def addMPlot(fig, M, idx, title, PersThrs, globalErrs, minv, maxv, tt=False):
    ax = fig.add_subplot(2, 3, idx)
    if idx > 3:
        colormap = plt.cm.RdYlBu_r
        minv = M.min()
        maxv = M.max()
        minv, maxv = findRange(minv, maxv)
    else:
        colormap = plt.cm.PuOr_r
    im = plt.imshow(M, cmap=colormap, alpha=.9, origin='lower', extent=[PersThrs[0]*100, PersThrs[-1]*100, globalErrs[0]*100,globalErrs[-1]*100], aspect='auto', vmin=minv, vmax=maxv)
    plt.title(title)
    plt.xlabel('persistence simplification (%)')
    plt.ylabel('maximum point-wise error (%)')
    if idx>3:
        divider = make_axes_locatable(ax)
        cax = divider.append_axes('right', size='5%', pad=0.05)
        cbar = fig.colorbar(im, cax=cax, orientation='vertical')
        cbar.ax.set_ylabel(tt, rotation=270, labelpad=10)
    return fig,im, ax

def addIMPlot(ax, M, title, PersThrs, globalErrs, minv,maxv):
    if 'PSNR' in title:
        colormap = plt.cm.RdYlBu_r
    else:
        colormap = plt.cm.PuOr_r
    im = ax.imshow(M, cmap=colormap, alpha=.9, origin='lower', extent=[PersThrs[0]*100, PersThrs[-1]*100, globalErrs[0]*100,globalErrs[-1]*100], aspect='auto', vmin=minv, vmax=maxv)
    plt.title(title)
    plt.xlabel('persistence simplification (%)')
    plt.ylabel('maximum point-wise error (%)')
    return im

def drawHeatMap(Ms, cmprs, title, PersThrs, globalErrs, figFile):
    minv,maxv = findExtreme(Ms)
    fig = plt.figure(figsize=(13, 7))
    fig,im,ax = addMPlot(fig, np.array(Ms[0]), 1, cmprs[0], PersThrs, globalErrs, minv,maxv)
    fig,im,ax2 = addMPlot(fig, np.array(Ms[1]), 2, cmprs[1], PersThrs, globalErrs, minv,maxv)
    fig,im,ax = addMPlot(fig, np.array(Ms[2]), 3, cmprs[2], PersThrs, globalErrs, minv,maxv)
    divider = make_axes_locatable(ax)
    cax = divider.append_axes('right', size='5%', pad=0.05)
    cbar = fig.colorbar(im, cax=cax, orientation='vertical')
    cbar.ax.set_ylabel(title, rotation=270, labelpad=10)
    
    fig,im,ax = addMPlot(fig, np.array(Ms[0])-np.array(Ms[2]), 4, cmprs[0] + ' vs. ' +  cmprs[2], PersThrs, globalErrs, minv,maxv, title)
    fig,im,ax = addMPlot(fig, np.array(Ms[1])-np.array(Ms[2]), 5, cmprs[1] + ' vs. ' +  cmprs[2], PersThrs, globalErrs, minv,maxv, title)
    fig,im,ax = addMPlot(fig, np.array(Ms[0])-np.array(Ms[1]), 6, cmprs[0] + ' vs. ' +  cmprs[1], PersThrs, globalErrs, minv,maxv, title)
    plt.tight_layout(pad=1.2, w_pad=1.2, h_pad=1.0)
    plt.savefig(figFile)
    

def plotHeatMap(inputDir, PersThrs, globalErrs):
    ebDir = os.path.join(inputDir, 'eb')
    ublbDir = os.path.join(inputDir, 'lbub')
    qzDir = os.path.join(inputDir, 'TopoQz')
    RIOs1 = []
    RIOs2 = []
    RIOs3 = []
    PRs1 = []
    PRs2 = []
    PRs3 = []
    
    for globalErr in globalErrs:
        ratios1, Fcnts1, PSNRs1, gErrs1 = readCmpInfo(os.path.join(ebDir, 'GlobalErr_' + str(globalErr)))
        ratios2, Fcnts2, PSNRs2, gErrs2 = readCmpInfo(os.path.join(ublbDir, 'GlobalErr_' + str(globalErr)))
        ratios3, Fcnts3, PSNRs3, gErrs3 = readCmpInfo(os.path.join(qzDir, 'GlobalErr_' + str(globalErr)))
        RIOs1.append(ratios1)
        RIOs2.append(ratios2)
        RIOs3.append(ratios3)
        PRs1.append(PSNRs1)
        PRs2.append(PSNRs2)
        PRs3.append(PSNRs3)
    
    minp,maxp = findExtreme([PRs1, PRs2, PRs3])
    figDir = os.path.join(inputDir, 'Figs')
    make_dir(figDir)
    figFile = os.path.join(figDir, "heatMap-CompressionRatio.png")
    drawHeatMap([RIOs1, RIOs2, RIOs3], ['TopoSZ-eb','TopoSZ-ublb', 'TopoQz'],  'Compression ratio', PersThrs, globalErrs, figFile)
    figFile = os.path.join(figDir, "heatMap-PSNR.png")
    drawHeatMap([PRs1, PRs2, PRs3], ['TopoSZ-eb','TopoSZ-ublb', 'TopoQz'],  'PSNR', PersThrs, globalErrs, figFile)
    
def plotLineChartCompressionRatioVSOthers_old(inputDir, PersThrs, globalErrs):
    ebDir = os.path.join(inputDir, 'eb')
    ublbDir = os.path.join(inputDir, 'lbub')
    qzDir = os.path.join(inputDir, 'TopoQz')
    RIOs1 = []
    RIOs2 = []
    RIOs3 = []
    
    PRs1 = []
    PRs2 = []
    PRs3 = []

    bDs1 = []
    bDs2 = []
    bDs3 = []

    wDs1 = []
    wDs2 = []
    wDs3 = []
    
    for globalErr in globalErrs:
        ratios1, Fcnts1, PSNRs1, gErrs1 = readCmpInfo(os.path.join(ebDir, 'GlobalErr_' + str(globalErr)))
        ratios2, Fcnts2, PSNRs2, gErrs2 = readCmpInfo(os.path.join(ublbDir, 'GlobalErr_' + str(globalErr)))
        ratios3, Fcnts3, PSNRs3, gErrs3 = readCmpInfo(os.path.join(qzDir, 'GlobalErr_' + str(globalErr)))
        
        bDist1, wDist1 = readPDDistFile(inputDir, 'eb', globalErr)
        bDist2, wDist2 = readPDDistFile(inputDir, 'lbub', globalErr)
        bDist3, wDist3 = readPDDistFile(inputDir, 'TopoQz', globalErr)
        
        RIOs1 += list(ratios1)
        RIOs2 += list(ratios2)
        RIOs3 += list(ratios3)

        PRs1 += list(PSNRs1)
        PRs2 += list(PSNRs2)
        PRs3 += list(PSNRs3)
        
        bDs1 += list(bDist1)
        bDs2 += list(bDist2)
        bDs3 += list(bDist3)

        wDs1 += list(wDist1)
        wDs2 += list(wDist2)
        wDs3 += list(wDist3)
    minv = max([min(RIOs1),min(RIOs2),min(RIOs3)])
    maxv = min([max(RIOs1),max(RIOs2),max(RIOs3)])
    print (min(RIOs1),min(RIOs2),min(RIOs3))
    print (max(RIOs1),max(RIOs2),max(RIOs3))
    cnt = 10
    steps = []
    for i in range(cnt+1):
        steps.append(minv+(maxv-minv)/cnt*i)

    P1 = []
    P2 = []
    P3 = []

    B1 = []
    B2 = []
    B3 = []

    W1 = []
    W2 = []
    W3 = []
    
    for step in steps:
        idx1 = find_nearest(RIOs1, step)
        idx2 = find_nearest(RIOs2, step)
        idx3 = find_nearest(RIOs3, step)
        
        P1.append(PRs1[idx1])
        P2.append(PRs2[idx2])
        P3.append(PRs3[idx3])

        B1.append(bDs1[idx1])
        B2.append(bDs2[idx2])
        B3.append(bDs3[idx3])

        W1.append(wDs1[idx1])
        W2.append(wDs2[idx2])
        W3.append(wDs3[idx3])

    figDir = os.path.join(inputDir, 'Figs')
    figFile = os.path.join(figDir, "CompressionRatioVSQuality.png")
    plotLineChart1r3c([[P1,P2,P3], [B1,B2,B3],[W1,W2,W3]], ['TopoSZ-eb','TopoSZ-ublb', 'TopoQz'], ["PSNR", "Bottleneck distance","Wasserstein distance (p=2)"], [steps, "compression ratio"], figFile)

def plotLineChartCompressionRatioVSOthers(inputDir, PersThrs, globalErrs):
    ebDir = os.path.join(inputDir, 'eb')
    ublbDir = os.path.join(inputDir, 'lbub')
    qzDir = os.path.join(inputDir, 'TopoQz')
    
    R1, Fcnts1, P1, gErrs1 = readCmpInfo(os.path.join(ebDir, 'GlobalErr_' + str(0.005)))
    R2, Fcnts2, P2, gErrs2 = readCmpInfo(os.path.join(ublbDir, 'combined'))
    R3, Fcnts3, P3, gErrs3 = readCmpInfo(os.path.join(qzDir, 'GlobalErr_' + str(0.1)))

    B1, W1 = readPDDistFile2(os.path.join(ebDir, 'GlobalErr_' + str(0.005)))
    B2, W2 = readPDDistFile2(os.path.join(ublbDir, 'combined'))
    B3, W3 = readPDDistFile2(os.path.join(qzDir, 'GlobalErr_' + str(0.1)))

    figDir = os.path.join(inputDir, 'Figs')
    figFile = os.path.join(figDir, "CompressionRatioVSQuality.png")
    plotLineChart1r3c([[P1,P2,P3], [B1,B2,B3],[W1,W2,W3]], ['TopoSZ-eb','TopoSZ-ublb', 'TopoQz'], ["PSNR", "Bottleneck distance","Wasserstein distance (p=2)"], [[R1, R2, R3], "compression ratio"], figFile)

def plotLineChartCompressionRatioVSOthersV2(inputDir, PersThrs, globalErrs, gErrs, PThrs):
    ebDir = os.path.join(inputDir, 'eb')
    ublbDir = os.path.join(inputDir, 'lbub')
    qzDir = os.path.join(inputDir, 'TopoQz')

    R1s, R2s, R3s,P1s,P2s,P3s, B1s,B2s,B3s,W1s,W2s,W3s=getInfoForPlot(ebDir, ublbDir, qzDir, gErrs)
    figDir = os.path.join(inputDir, 'Figs')
    figFile = os.path.join(figDir, "CompressionRatioVSQualityFixedgErrs.png")
    plotLineChart1r3cV2([[P1s,P2s,P3s], [B1s,B2s,B3s],[W1s,W2s,W3s]], ['TopoSZ-eb','TopoSZ-ublb', 'TopoQz'], ["PSNR", "Bottleneck distance","Wasserstein distance (p=2)"], [[R1s, R2s, R3s], "compression ratio"], gErrs, figFile)

    R1s, R2s, R3s,P1s,P2s,P3s, B1s,B2s,B3s,W1s,W2s,W3s=getInfoForPlot(ebDir, ublbDir, qzDir, globalErrs)
    pThrs = [PersThrs.index(i) for i in PThrs]
    R1s = R1s[:,pThrs].T
    R2s = R2s[:,pThrs].T
    R3s = R3s[:,pThrs].T

    P1s = P1s[:,pThrs].T
    P2s = P2s[:,pThrs].T
    P3s = P3s[:,pThrs].T

    B1s = B1s[:,pThrs].T
    B2s = B2s[:,pThrs].T
    B3s = B3s[:,pThrs].T

    W1s = W1s[:,pThrs].T
    W2s = W2s[:,pThrs].T
    W3s = W3s[:,pThrs].T

    figFile = os.path.join(figDir, "CompressionRatioVSQualityFixedpThrs.png")
    plotLineChart1r3cV2([[P1s,P2s,P3s], [B1s,B2s,B3s],[W1s,W2s,W3s]], ['TopoSZ-eb','TopoSZ-ublb', 'TopoQz'], ["PSNR", "Bottleneck distance","Wasserstein distance (p=2)"], [[R1s, R2s, R3s], "compression ratio"], gErrs, figFile)

    

def getInfoForPlot(ebDir, ublbDir, qzDir, gErrs):
    R1s = []
    R2s = []
    R3s = []
    P1s = []
    P2s = []
    P3s = []
    B1s = []
    B2s = []
    B3s = []
    W1s = []
    W2s = []
    W3s = []
    for gErr in gErrs:
        R1, Fcnts1, P1, gErrs1 = readCmpInfo(os.path.join(ebDir, 'GlobalErr_' + str(gErr)),1)
        R2, Fcnts2, P2, gErrs2 = readCmpInfo(os.path.join(ublbDir, 'GlobalErr_' + str(gErr)),1)
        R3, Fcnts3, P3, gErrs3 = readCmpInfo(os.path.join(qzDir, 'GlobalErr_' + str(gErr)),1)
        B1, W1 = readPDDistFile2(os.path.join(ebDir, 'GlobalErr_' + str(gErr)),1)
        B2, W2 = readPDDistFile2(os.path.join(ublbDir, 'GlobalErr_' + str(gErr)),1)
        B3, W3 = readPDDistFile2(os.path.join(qzDir, 'GlobalErr_' + str(gErr)),1)
        R1s.append(R1)
        R2s.append(R2)
        R3s.append(R3)
        P1s.append(P1)
        P2s.append(P2)
        P3s.append(P3)
        B1s.append(B1)
        B2s.append(B2)
        B3s.append(B3)
        W1s.append(W1)
        W2s.append(W2)
        W3s.append(W3)
    return np.array(R1s),np.array(R2s),np.array(R3s),np.array(P1s),np.array(P2s),np.array(P3s),np.array(B1s),np.array(B2s),np.array(B3s) ,np.array(W1s),np.array(W2s),np.array(W3s) 
    

def plotLineChart1r3cV2(Ls, cmps, titles, xInfo, gErrs, figFile):
    lwid = 2
    ltypes = ['solid', 'dashed', 'dotted']
    colors = ['royalblue', 'orange', 'g']
    markers = ['o','^', 's']
    fig = plt.figure(figsize=(13, 4))
    for i in range(3):
        ax = fig.add_subplot(1, 3, i+1)
        for j in range(len(gErrs)):
            plt.plot(np.array(xInfo[0][0][j]), Ls[i][0][j], color=colors[0], linestyle=ltypes[j],marker=markers[0], linewidth=lwid,markersize=4, label=cmps[0])
            plt.plot(np.array(xInfo[0][1][j]), Ls[i][1][j], color=colors[1], linestyle=ltypes[j],marker=markers[1], linewidth=lwid,markersize=4, label=cmps[1])
            plt.plot(np.array(xInfo[0][2][j]), Ls[i][2][j], color=colors[2], linestyle=ltypes[j],marker=markers[2], linewidth=lwid,markersize=4, label=cmps[2])
        plt.title(titles[i])
        plt.grid(color='gray', linestyle='-', linewidth=0.1)
        plt.xlabel(xInfo[1])
        plt.ylabel(titles[i])
        plt.legend()
    plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
    #plt.show()
    plt.savefig(figFile)

def plotLineChart1r3c(Ls, cmps, titles, xInfo, figFile):
    lwid = 2
    fig = plt.figure(figsize=(13, 4))
    for i in range(3):
        ax = fig.add_subplot(1, 3, i+1)
        plt.plot(np.array(xInfo[0][0]), Ls[i][0],'o-', linewidth=lwid, label=cmps[0])
        plt.plot(np.array(xInfo[0][1]), Ls[i][1],'o-', linewidth=lwid, label=cmps[1])
        plt.plot(np.array(xInfo[0][2]), Ls[i][2],'o-', linewidth=lwid, label=cmps[2])
        plt.title(titles[i])
        plt.grid(color='gray', linestyle='-', linewidth=0.1)
        plt.xlabel(xInfo[1])
        plt.ylabel(titles[i])
        plt.legend()
    plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
    plt.savefig(figFile)
    
    
def plotLineChartForTopoCompressor(inputDir, inputDir2, inputDir3, PersThrs, globalErr, figFile):
    lwid = 2
    ratios1, Fcnts1, PSNRs1, gErrs1 = readCmpInfo(inputDir)
    ratios2, Fcnts2, PSNRs2, gErrs2 = readCmpInfo(inputDir2)
    ratios3, Fcnts3, PSNRs3, gErrs3 = readCmpInfo(inputDir3)
    
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(2, 2, 1)
    plt.plot(PersThrs, ratios1, linewidth=lwid, label='TopoSZ-eb')
    plt.plot(PersThrs, ratios2, linewidth=lwid, label='TopoSZ-ublb')
    plt.plot(PersThrs, ratios3, linewidth=lwid, label='TopoQz')
    plt.title("Compression Ratio")
    plt.grid(color='gray', linestyle='-', linewidth=0.1)
    plt.xlabel("Persistence threshold")
    plt.ylabel("compression ratio")
    plt.legend()

    ax = fig.add_subplot(2, 2, 2)
    plt.plot(PersThrs, PSNRs1, linewidth=lwid, label='TopoSZ-eb')
    plt.plot(PersThrs, PSNRs2, linewidth=lwid, label='TopoSZ-ublb')
    plt.plot(PersThrs, PSNRs3, linewidth=lwid, label='TopoQz')
    plt.title("PSNR")
    plt.grid(color='gray', linestyle='-', linewidth=0.1)
    plt.xlabel("Persistence threshold")
    plt.ylabel("PSNR")
    plt.legend()
    
    ax = fig.add_subplot(2, 2, 3)
    plt.plot(PersThrs, np.sum(Fcnts1, axis=1), linewidth=lwid, label='TopoSZ-eb')
    plt.plot(PersThrs, np.sum(Fcnts2, axis=1), linewidth=lwid, label='TopoSZ-ublb')
    plt.plot(PersThrs, np.sum(Fcnts3, axis=1), linewidth=lwid, label='TopoQz')
    plt.title("Overall occurrence of FPs, FNs, FTs")
    plt.grid(color='gray', linestyle='-', linewidth=0.1)
    plt.xlabel("Persistence threshold")
    plt.ylabel("#")
    plt.legend()

    ax = fig.add_subplot(2, 2, 4)
    gErrs = np.ones(len(gErrs1))* globalErr
    plt.plot(PersThrs, gErrs1, linewidth=lwid, label='TopoSZ-eb')
    plt.plot(PersThrs, gErrs2, linewidth=lwid, label='TopoSZ-ublb')
    plt.plot(PersThrs, gErrs3, linewidth=lwid, label='TopoQz')
    plt.plot(PersThrs, gErrs, linewidth=lwid, label='Given global error')
    plt.title("Maximum Pointwise Error")
    plt.grid(color='gray', linestyle='-', linewidth=0.1)
    plt.xlabel("Persistence threshold")
    plt.ylabel("Maximum pointwise error")
    plt.legend()
    ax.set_yscale('log')
    plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
    #plt.show()
    plt.savefig(figFile)

def plotLineChartForEbAndUblb(l1, l2, PersThrs, globalErrs, figFile, title):
    lwid = 2
    fig = plt.figure(figsize=(10, 8))
    for i in range(len(l1)):
         ax = fig.add_subplot(2, 2, i+1)
         plt.plot(PersThrs, l1[i], linewidth=lwid, label='TopoSZ: eb')
         plt.plot(PersThrs, l2[i], linewidth=lwid, label='TopoSZ: ublb')
         plt.title("Global error = " + str(globalErrs[i]))
         plt.grid(color='gray', linestyle='-', linewidth=0.1)
         plt.xlabel("Persistence threshold")
         plt.ylabel(title)
         plt.legend()
    plt.tight_layout(pad=0.4, w_pad=0.5, h_pad=1.0)
    #plt.show()
    plt.savefig(figFile)
    
# Used for checking.
def plotSortedRegion(sortedRegion, w,h):
    l = np.zeros(w*h)
    for i in range(len(sortedRegion)):
        l[sortedRegion[i]]=1
    plotM(l.reshape(h,w))
    
## Just used once.
def plotErrBoundsForExitTalk(M1, M2, title, figFile):
    minv = min(np.min(M1), np.min(M2))
    maxv = max(np.max(M1), np.max(M2))
    fig = plt.figure(figsize=(12, 8))
    ax2 = plt.subplot(1, 1, 1)
    plt.imshow(M2, vmin=minv, vmax=maxv, cmap=plt.cm.viridis, alpha=.9, origin='lower')
    plt.axis('off')
    plt.show()
    plt.savefig(figFile)
