from PKG import *
""" Functions used accross *util.py
"""

def make_dir(new_dir):
    if not os.path.exists(new_dir):
        os.makedirs(new_dir)

def saveToDatFloat32(scalar, outFile):
    sf = np.array(scalar, 'float32')
    output_file = open(outFile, 'wb')
    sf.tofile(output_file)
    output_file.close()

def saveToDatDouble(scalar, outFile):
    sf = np.array(scalar, 'double')
    output_file = open(outFile, 'wb')
    sf.tofile(output_file)
    output_file.close()

def normalized(magn):
    maxv = max(magn)
    minv = min(magn)
    return (magn-minv)/(maxv-minv)

def calculatePSNR(sf1, sf2):
    MSE = mean_squared_error(sf1, sf2)
    maxv = max(sf1)
    minv = min(sf1)
    if MSE == 0:
        return float('inf')
    else:
        psnr = 20*math.log((maxv-minv), 10)-10*math.log(MSE, 10)
    return psnr

def writeCmpInfo(fileDir, ratios, Fcnts, PSNRs, gErrs):
    ratioFile = os.path.join(fileDir, 'compressionRatio.txt')
    FcntFile = os.path.join(fileDir, 'FPFNFT.txt')
    gErrFile = os.path.join(fileDir, 'globalErr.txt')
    psnrFile = os.path.join(fileDir, 'PSNR.txt')
    np.savetxt(ratioFile, np.array(ratios), fmt="%.2f")
    np.savetxt(FcntFile, np.array(Fcnts), fmt="%d")
    np.savetxt(psnrFile, np.array(PSNRs), fmt="%.2f")
    np.savetxt(gErrFile, np.array(gErrs), fmt="%.6f")

def writeCmpInfo2(fileDir, ratios, Fcnts, PSNRs, gErrs, IterNum):
    ratioFile = os.path.join(fileDir, 'compressionRatio.txt')
    FcntFile = os.path.join(fileDir, 'FPFNFT.txt')
    gErrFile = os.path.join(fileDir, 'globalErr.txt')
    psnrFile = os.path.join(fileDir, 'PSNR.txt')
    iterFile = os.path.join(fileDir, 'IterNum.txt')
    np.savetxt(ratioFile, np.array(ratios), fmt="%.2f")
    np.savetxt(FcntFile, np.array(Fcnts), fmt="%d")
    np.savetxt(psnrFile, np.array(PSNRs), fmt="%.2f")
    np.savetxt(gErrFile, np.array(gErrs), fmt="%.6f")
    np.savetxt(iterFile, np.array(IterNum), fmt="%d")

def readCmpInfo(fileDir, skipFirst=False):
    ratioFile = os.path.join(fileDir, 'compressionRatio.txt')
    FcntFile = os.path.join(fileDir, 'FPFNFT.txt')
    gErrFile = os.path.join(fileDir, 'globalErr.txt')
    psnrFile = os.path.join(fileDir, 'PSNR.txt')
    ratios = np.loadtxt(ratioFile)
    Fcnts = np.loadtxt(FcntFile)
    gErrs = np.loadtxt(gErrFile)
    PSNRs = np.loadtxt(psnrFile)
    if len(ratios.shape)>0:
        if skipFirst:
            return ratios[1:], Fcnts[1:], PSNRs[1:], gErrs[1:]
        else:
            return ratios, Fcnts, PSNRs, gErrs
    else:
        return [ratios], [Fcnts], [PSNRs], [gErrs]

    
def readTopoCmpInfo(fileDir, skipFirst=False):
    ratioFile = os.path.join(fileDir, 'compressionRatio.txt')
    psnrFile = os.path.join(fileDir, 'PSNR.txt')
    dBFile = os.path.join(fileDir, 'bDist.txt')
    dWFile = os.path.join(fileDir, 'wDist.txt')
    ratios = np.loadtxt(ratioFile)
    PSNRs = np.loadtxt(psnrFile)
    dB = np.loadtxt(dBFile)
    dW = np.loadtxt(dWFile)
    print (ratioFile)
    print (ratios.shape)
    if len(ratios.shape)>0:
        if skipFirst:
            return ratios[1:], Fcnts[1:], PSNRs[1:], gErrs[1:]
        else:
            return ratios,  PSNRs, dB, dW
    else:
        return [ratios], [Fcnts], [PSNRs], [gErrs]
    
def findPDFile(data_dir):
    files = os.listdir(data_dir)
    for i in files:
        if 'PD' in i:
            return i
    return False

def getPDFileDir(fileDir):
    topoInfoDir = os.path.join(fileDir, "TopoInfo")
    topoInfo = findPDFile(topoInfoDir)
    return os.path.join(topoInfoDir, topoInfo)

def readPDDistFile(inputDir, cmpr, globalErr):
    TopoCompDir = os.path.join(inputDir, cmpr)
    gTopoCompDir = os.path.join(TopoCompDir, 'GlobalErr_' + str(globalErr))
    wDistFile = os.path.join(gTopoCompDir, 'wDist.txt')
    bDistFile = os.path.join(gTopoCompDir, 'bDist.txt')
    bdist = np.loadtxt(bDistFile)
    wdist = np.loadtxt(wDistFile)
    if len(bdist.shape)>0:
        return  bdist, wdist
    else:
        return [bdist], [wdist]

def readPDDistFile2(gTopoCompDir, skipFirst=False):
    wDistFile = os.path.join(gTopoCompDir, 'wDist.txt')
    bDistFile = os.path.join(gTopoCompDir, 'bDist.txt')
    bdist = np.loadtxt(bDistFile)
    wdist = np.loadtxt(wDistFile)
    if len(bdist.shape)>0:
        if skipFirst:
            return  bdist[1:], wdist[1:]
        else:
            return  bdist, wdist
    else:
        return [bdist], [wdist]

def writeCheckingFile(inputDir, globalErr, checking, ratios, PersThrs):
    globalDir = os.path.join(inputDir, 'GlobalErr_' + str(globalErr))
    checkingFile = os.path.join(globalDir, 'checkingFile.txt')
    with open(checkingFile, "w+") as file:
        file.write("Global error bound: %.3f\n\n"% (globalErr))
        for i in range(len(checking)):
            file.write("Simplification threshold: %.4f; Compression ratio: %.4f; Iteration times: %d; Status: %s\n"% (PersThrs[i],ratios[i], checking[i][1], checking[i][0]))

def writeTimeFile(timeFile, tTime, IterNum):
    if  IterNum ==0:
        IterNum=1
    with open(timeFile, "w+") as file:
        file.write("& %.2f & %.2f & %.2f & %d\n"% (tTime[0]/IterNum,tTime[1]/IterNum,tTime[2]/IterNum, IterNum))

def writeTimeFile2(timeFile, tTime, IterNum):
    with open(timeFile, "w+") as file:
        if IterNum == 0:
            file.write("& %.2f & %.2f & %.2f & - & - & - & 0\n"% (tTime[0],tTime[1],tTime[2]))
        else:
            file.write("& %.2f & %.2f & %.2f & %.2f & %.2f & %.2f & %d\n"% (tTime[0],tTime[1],tTime[2],tTime[3]/IterNum,tTime[4]/IterNum,tTime[5]/IterNum, IterNum))
        
def updateCTTime(t1, t2, t3, timeDir):
    t1_,t2_,t3_ = np.loadtxt(os.path.join(timeDir, 'ctTime.txt'))
    t1 = t1+t1_
    t2 = t2+t2_
    t3 = t3+t3_
    return t1, t2, t3

def findExtreme(L):
    minv = 9999
    maxv= -9999
    for ll in L:
        for l in ll:
            minl = min(l)
            maxl = max(l)
            if minl<minv:
                minv = minl
            if maxl>maxv:
                maxv = maxl
    return minv, maxv

def findRange(minv, maxv):
    absv = max(abs(minv),abs(maxv))
    return -absv, absv

def find_nearest(array, value):
    array = np.asarray(array)
    idx = (np.abs(array - value)).argmin()
    return idx

def cleanFolder(fDir):
    tdaDir = os.path.join(fDir,'TDA')
    if os.path.exists(tdaDir):
        shutil.rmtree(tdaDir)
    for filename in glob.glob(os.path.join(fDir,'*.dat')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.sz')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.cmp')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.out')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.config')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'crits*')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'edges*')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'segms*')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.vtu')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.vti')):
        os.remove(filename) 

def cleanFolderTopoQz(fDir):
    for filename in glob.glob(os.path.join(fDir,'*.vti')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.vtu')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.ttk')):
        os.remove(filename)
    for filename in glob.glob(os.path.join(fDir,'*.vtk')):
        os.remove(filename)
    tdaDir = os.path.join(fDir,'TDA')
    if os.path.exists(tdaDir):
        shutil.rmtree(tdaDir)
