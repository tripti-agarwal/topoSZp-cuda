import vtk
from vtk.util.numpy_support import vtk_to_numpy
from vtk.util.numpy_support import numpy_to_vtk
from functions_util import *

def readSegmSFData(vtuFile, scalarField):
    reader = vtk.vtkStructuredPointsReader()
    reader.SetFileName(vtuFile)
    reader.Update()

    VTU = reader.GetOutput()
    scalar = vtk_to_numpy(VTU.GetPointData().GetArray(scalarField))
    segmID = vtk_to_numpy(VTU.GetPointData().GetArray('SegmentationId'))
    return scalar, segmID

def readSegmData(vtuFile):
    reader = vtk.vtkStructuredPointsReader()
    reader.SetFileName(vtuFile)
    reader.Update()

    VTU = reader.GetOutput()
    segmID = vtk_to_numpy(VTU.GetPointData().GetArray('SegmentationId'))
    return segmID

def readCritsData(critsFile):
    reader = vtk.vtkUnstructuredGridReader()
    reader.SetFileName(critsFile)
    reader.Update()

    crits = reader.GetOutput()
    critsID = vtk_to_numpy(crits.GetPointData().GetArray('VertexId'))
    nodesID = vtk_to_numpy(crits.GetPointData().GetArray('NodeId'))
    critsType = vtk_to_numpy(crits.GetPointData().GetArray('CriticalType'))
    return critsID, critsType, nodesID.tolist()

def readEdgesData(edgesFile):
    reader = vtk.vtkUnstructuredGridReader()
    reader.SetFileName(edgesFile)
    reader.Update()
    
    Tree = reader.GetOutput()
    upNodesID = vtk_to_numpy(Tree.GetCellData().GetArray('upNodeId'))
    downNodesID = vtk_to_numpy(Tree.GetCellData().GetArray('downNodeId'))
    links = np.concatenate(([upNodesID.reshape(len(upNodesID),)], [downNodesID.reshape(len(upNodesID),)]), axis=0).T
    return links


def readScalarFromVTI(inputFileDir, scalarField):
    vtkType = inputFileDir.split('.')[-1]
    if vtkType == 'vti':
        reader = vtk.vtkXMLImageDataReader()
    elif vtkType == 'vtp':
        reader = vtk.vtkXMLPolyDataReader()
    else:
        reader = vtk.vtkXMLUnstructuredGridReader()
    reader.SetFileName(inputFileDir) 
    reader.Update()
    scalar = vtk_to_numpy(reader.GetOutput().GetPointData().GetArray(scalarField))
    return scalar 


def saveToSF(inputDir, inputFileName, sf):
    inputFileDir = os.path.join(inputDir, inputFileName)
    vtkType = inputFileName.split('.')[-1]
    if vtkType == 'vti':
        reader = vtk.vtkXMLImageDataReader()
    else:
        reader = vtk.vtkXMLUnstructuredGridReader()
    reader.SetFileName(inputFileDir) 
    reader.Update()
    outDir = os.path.join(inputDir, 'ClassicSZ')
    make_dir(outDir)
    polydata = reader.GetOutput()
    vf = vtk_to_numpy(polydata.GetPointData().GetArray(sf))
    
    if len(vf.shape) > 1:
        magn = np.linalg.norm(vf, axis=1)
        magn = normalized(magn)
        scalar = magn
    else:
        scalar = vf
    saveToDatFloat32(scalar, os.path.join(inputDir, 'sf.dat'))
    return scalar

def saveToVTP(inputDir, inputFileName, scalar, n, m):
    outFileName = os.path.join(inputDir, inputFileName.split('.')[0]+'.vtp')
    xmin = 0
    xmax = n
    ymin = 0
    ymax = m
    x = np.linspace(xmin, xmax, n)
    y = np.linspace(ymin, ymax, m)
    x, y = np.meshgrid(x, y)
    x, y = x.flatten(), y.flatten()
    z = scalar
    
    plane = vtk.vtkPlaneSource()
    plane.SetResolution(n-1,m-1)
    plane.SetOrigin([xmin,ymin,0])  # Lower left corner
    plane.SetPoint1([xmax,ymin,0])
    plane.SetPoint2([xmin,ymax,0])
    plane.Update()
    
    nPoints = plane.GetOutput().GetNumberOfPoints()
    assert(nPoints == len(z))
    scalars = vtk.vtkFloatArray()
    scalars.SetNumberOfValues(nPoints)
    for i in range(nPoints):
        scalars.SetValue(i, z[i])
    plane.GetOutput().GetPointData().SetScalars(scalars)

    scalarArray = numpy_to_vtk(scalar)
    scalarArray.SetName("velocityMagnitude")
    plane.GetOutput().GetPointData().AddArray(scalarArray)
    
    writer = vtk.vtkXMLPolyDataWriter()
    writer.SetFileName(outFileName)
    writer.SetInputConnection(plane.GetOutputPort())
    writer.Write()


def saveDecompressedToFile(scalar, sfs, outFile, reader, vtkType, titles):
    if vtkType == 'vti':
        dataSet = vtk.vtkImageData()
    elif vtkType == 'vtp':
        dataSet = vtk.vtkPolyData()
    else:
        dataSet = vtk.vtkUnstructuredGrid()
    dataSet.CopyStructure(reader.GetOutput())
  
    for i in range(len(sfs)):
        sf = sfs[i]
        scalarArray = numpy_to_vtk(sf)
        scalarArray.SetName("velocityMagnitude-Decompressed"+titles[i])
        dataSet.GetPointData().AddArray(scalarArray)

    scalarArray = numpy_to_vtk(scalar)
    scalarArray.SetName("velocityMagnitude-original")
    dataSet.GetPointData().AddArray(scalarArray)

    if vtkType == 'vti':
        writer = vtk.vtkXMLImageDataWriter()
    elif vtkType == 'vtp':
        writer = vtk.vtkXMLPolyDataWriter()
    else:
        writer = vtk.vtkXMLUnstructuredGridWriter()

    writer.SetInputData(dataSet)
    writer.SetFileName(outFile)
    writer.Write()
    
            
def getDimsFromVTK(inputFileDir):
    vtkType = inputFileDir.split('.')[-1]
    if vtkType == 'vti':
        reader = vtk.vtkXMLImageDataReader()
    else:
        reader = vtk.vtkXMLUnstructuredGridReader()
    reader.SetFileName(inputFileDir) 
    reader.Update()

    polydata = reader.GetOutput()
    return polydata.GetDimensions()

def saveTreeFile(treeFile, nodesFile, edgesFile, treeType):
    reader = vtk.vtkUnstructuredGridReader()
    reader.SetFileName(treeFile)
    reader.Update()

    Tree = reader.GetOutput()
    nodes = Tree.GetPoints()
    scalar =  vtk_to_numpy(Tree.GetPointData().GetArray("Scalar"))
    if treeType == 'st':
        scalar = 1000 - scalar
    nodes = vtk_to_numpy(nodes.GetData())
    edges = Tree.GetCells()
    edges = vtk_to_numpy(edges.GetData())
    array_len = edges[0]
    links = []
    ecnt = int(len(edges)/(array_len+1))
    for j in range(0, ecnt):
        links.append([edges[j*(array_len+1)+1], edges[j*(array_len+1)+2]])
    links = np.array(links)
    nodes = np.concatenate((nodes, np.array([scalar]).T), axis=1)

    np.savetxt(nodesFile, nodes, fmt='%.6f')
    np.savetxt(edgesFile, links, fmt='%d')

def savePDFile(PDVTUFil, PDFile):
    reader = vtk.vtkXMLUnstructuredGridReader()
    reader.SetFileName(PDVTUFil)
    reader.Update()

    VTU = reader.GetOutput()
    nodes = VTU.GetPoints()
    nodes = vtk_to_numpy(nodes.GetData())
    PDs = []
    for i in range(len(nodes)):
        if nodes[i][0]<nodes[i][1]:
            PDs.append([nodes[i][0], nodes[i][1]])
    PDs = np.array(PDs)
    np.savetxt(PDFile, PDs, fmt='%.10f')

def getOriginalStructural(inputFileDir):
    vtkType = inputFileDir.split('.')[-1]
    if vtkType == 'vti':
        reader = vtk.vtkXMLImageDataReader()
    elif vtkType == 'vtp':
        reader = vtk.vtkXMLPolyDataReader()
    else:
        reader = vtk.vtkXMLUnstructuredGridReader()
    reader.SetFileName(inputFileDir) 
    reader.Update()
    return reader, vtkType
    
def savePersistenceDiagramAndMergeTree(inputDir, vtpFile, scalarField, outputDir=False):
    cmd = 'pvpython ./src/pvSavePDAndMT.py ' + inputDir + '/ ' + vtpFile + ' ' + scalarField
    os.system(cmd)

    if not outputDir:
        outputDir = inputDir
    
    topoInfoDir = os.path.join(outputDir, "TopoInfo")
    make_dir(topoInfoDir)
    
    EdgesSTFile =  inputDir + "/edgesST_" + vtpFile.split('.')[0] + '.vtk'
    nodesFile = os.path.join(topoInfoDir, "stNodes_" + vtpFile.split('.')[0] + '.txt')
    edgesFile = os.path.join(topoInfoDir, "stEdges_" + vtpFile.split('.')[0] + '.txt')
    saveTreeFile(EdgesSTFile, nodesFile, edgesFile, 'st')

    EdgesJTFile = inputDir + "/edgesJT_" + vtpFile.split('.')[0] + '.vtk'
    nodesFile = os.path.join(topoInfoDir, "jtNodes_" + vtpFile.split('.')[0] + '.txt')
    edgesFile = os.path.join(topoInfoDir, "jtEdges_" + vtpFile.split('.')[0] + '.txt')
    saveTreeFile(EdgesJTFile, nodesFile, edgesFile, 'jt')
    
    PDVTUFile = inputDir + "/PD_" + vtpFile.split('.')[0] + '.vtu'
    PDFile = os.path.join(topoInfoDir, "PD_" + vtpFile.split('.')[0] + '.txt')
    savePDFile(PDVTUFile, PDFile)

def addScalar(reader, dataSet, scalarName, sf):
    scalarArray = numpy_to_vtk(sf)
    scalarArray.SetName(scalarName)
    dataSet.GetPointData().AddArray(scalarArray)
    return dataSet
    
def addMagnitude(inputFile):
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName(inputFile) 
    reader.Update()

    x = vtk_to_numpy(reader.GetOutput().GetPointData().GetArray('u'))
    y = vtk_to_numpy(reader.GetOutput().GetPointData().GetArray('v'))
    z = vtk_to_numpy(reader.GetOutput().GetPointData().GetArray('w'))

    magn = np.zeros(len(x))
    for i in range(len(x)):
        magn[i] = math.sqrt(x[i]**2+y[i]**2+z[i]**2)
    npArray = np.array(magn)
    npArray = (npArray-min(npArray))/(max(npArray)-min(npArray))
    sfs = [x, y, z]
    scalars = ['u', 'v', 'w']
    dataSet = vtk.vtkImageData()
    dataSet.CopyStructure(reader.GetOutput())
    for i in range(len(scalars)):
        dataSet = addScalar(reader, dataSet, scalars[i], sfs[i])
    scalarArray = numpy_to_vtk(npArray)
    scalarArray.SetName("velocityMagnitude")
    dataSet.GetPointData().AddArray(scalarArray)

    writer = vtk.vtkXMLImageDataWriter()
    writer.SetInputData(dataSet)
    writer.SetFileName(inputFile)
    writer.Write()

def normalizeVTK(inputFile, scalarField):
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName(inputFile) 
    reader.Update()

    sf = normalized(vtk_to_numpy(reader.GetOutput().GetPointData().GetArray(scalarField)))

    dataSet = vtk.vtkImageData()
    dataSet.CopyStructure(reader.GetOutput())
    dataSet = addScalar(reader, dataSet, scalarField, sf)

    writer = vtk.vtkXMLImageDataWriter()
    writer.SetInputData(dataSet)
    writer.SetFileName(inputFile)
    writer.Write()
