#!/usr/bin/env pvpython

import sys
import math
import vtk
from vtk.util.numpy_support import vtk_to_numpy
import os
from paraview.simple import *

inputDir = sys.argv[1]
scalarField = sys.argv[2]
outputDir = sys.argv[3]
PersThr = float(sys.argv[4])
globalErr = float(sys.argv[5])

inputData = XMLImageDataReader(FileName=[inputDir])
SaveData(outputDir, proxy=inputData, ScalarField=scalarField, Topologicallosspersistencepercentage=PersThr,Enablemaximumpointwiseerrorcontrol=1, Maximumpointwiseerrorpercentage=globalErr)
