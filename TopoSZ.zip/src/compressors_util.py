from functions_util import *
from tda_util import *
from plot_util import *
from vtk_util import *

def runSZ(outDir, scalarOriginal, errs, idx, w, h, szType):
    saveToDatFloat32(scalarOriginal, os.path.join(outDir, 'sf'+str(idx)+'.dat'))
    saveToDatDouble(np.array(errs), os.path.join(outDir, 'err'+str(idx)+'.dat'))
    base_eb = ''
    base_eb = ' 1e-9'
    if szType == 'eb':
        cmd = 'sz_compress_2d_with_eb ' + os.path.join(outDir, 'sf'+str(idx)+'.dat') + ' ' + os.path.join(outDir, 'err'+str(idx)+'.dat') + ' ' +str(h) + ' ' + str(w) + ' 1 ' +  base_eb
    else:
        cmd = 'sz_compress_2d_with_eb_ct ' + os.path.join(outDir, 'sf'+str(idx)+'.dat') + ' ' + os.path.join(outDir, 'err'+str(idx)+'.dat') + ' '  +str(h) + ' ' + str(w) + ' 1 ' +  base_eb + ' 0 ' +os.path.join(outDir, 'UpperErr'+str(idx)+'.dat') + ' ' + os.path.join(outDir, 'LowerErr'+str(idx)+'.dat')
    os.system(cmd)

def runSZ3D(outDir, scalarOriginal, errs, idx, w, h, l, szType):
    saveToDatFloat32(scalarOriginal, os.path.join(outDir, 'sf'+str(idx)+'.dat'))
    saveToDatDouble(np.array(errs), os.path.join(outDir, 'err'+str(idx)+'.dat'))
    base_eb = ''
    base_eb = ' 0.000000001'
    if szType == 'eb':
        cmd = 'sz_compress_3d_with_eb ' + os.path.join(outDir, 'sf'+str(idx)+'.dat') + ' ' + os.path.join(outDir, 'err'+str(idx)+'.dat') + ' '+str(l) + ' ' +str(h) + ' ' + str(w) + ' 1' +  base_eb
    else:
        cmd = 'sz_compress_3d_with_eb_ct ' + os.path.join(outDir, 'sf'+str(idx)+'.dat') + ' ' + os.path.join(outDir, 'err'+str(idx)+'.dat')+ ' ' +str(l) + ' ' +str(h) + ' ' + str(w) + ' 0 ' +  base_eb + ' 0 ' + os.path.join(outDir, 'UpperErr'+str(idx)+'.dat') + ' ' + os.path.join(outDir, 'LowerErr'+str(idx)+'.dat')
        print (cmd)
    os.system(cmd)

"""
def modifyConfigFile(workingDir, globalErr):
    configFile = os.path.join('./src/', 'sz.config')
    f = open(configFile, 'r')  
    lines = f.readlines()
    for i in range(len(lines)):
        if lines[i][0:11]=='absErrBound':
            lines[i] = 'absErrBound = ' + str(globalErr)
    f.close()
    newConfigFile = os.path.join(workingDir, 'sz.config')
    f = open(newConfigFile, 'w')
    f.writelines(lines)
    f.close()
"""

def compressWithCmp(inputDir,workingDir, w, h, l, globalErr, compressor):
    if compressor == "ClassicSZ":
        if l == 0:
            #Old version: new version should be sz3
            #cmd = 'sz -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -f -c ./src/sz.config -M ABS -A ' +str(globalErr) + ' -i ' + os.path.join(inputDir, 'sf.dat') + ' -2 ' + str(h) + ' ' + str(w)
            cmd = 'sz3 -f -i ' + os.path.join(inputDir, 'sf.dat') + ' -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -2 ' + str(w) + ' ' + str(h) + ' -M ABS ' +str(globalErr) 
        else:
            #cmd = 'sz -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -f -c ./src/sz.config -M ABS -A ' +str(globalErr) + ' -i ' + os.path.join(inputDir, 'sf.dat') + ' -3 ' + str(l) + ' ' + str(h) + ' ' + str(w)
            cmd = 'sz3 -f -i ' + os.path.join(inputDir, 'sf.dat') + ' -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -3 ' + str(w) + ' ' + str(h) + ' ' + str(l) + ' -M ABS ' +str(globalErr) 
    elif compressor == "ZFP":
        if l == 0:
            cmd = 'zfp -i ' + os.path.join(inputDir, 'sf.dat') + ' -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -f -2 ' + str(w) + ' ' + str(h) + ' -a ' +str(globalErr)
        else:
            cmd = 'zfp -i ' + os.path.join(inputDir, 'sf.dat') + ' -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -f -3 '  + str(w) + ' ' + str(h) + ' ' + str(l) + ' -a ' +str(globalErr)
    elif compressor == "FPZIP":
        if l == 0:
            cmd = 'fpzip -i ' + os.path.join(inputDir, 'sf.dat') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -p ' + str(globalErr) + ' -2 ' + str(w) + ' ' + str(h)
        else:
            cmd = 'fpzip -i ' + os.path.join(inputDir, 'sf.dat') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -p ' + str(globalErr) + ' -3 ' + str(w) + ' ' + str(h) + ' ' + str(l)
    else:
        cmd = ' '
    os.system(cmd)
    print (cmd)
    if compressor == "ClassicSZ":
        if l == 0:
            cmd = 'sz3 -x -f -s ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -2 ' + str(w) + ' ' + str(h)
        else:
            cmd = 'sz3 -x -f -s ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -3 ' + str(w) + ' ' + str(h) + ' ' + str(l)
    elif compressor == "ZFP":
        if l == 0:
            cmd = 'zfp -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out') + ' -f -2 ' + str(w) + ' ' + str(h) + ' -a ' +str(globalErr)
        else:
            cmd = 'zfp -z ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out') + ' -f -3 '+ str(w) + ' '  + str(h) + ' ' + str(l) + ' -a ' +str(globalErr)
    elif compressor == "FPZIP":
        if l == 0:
            cmd = 'fpzip -d -i ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out') + ' -2 ' + str(w) + ' ' + str(h)
        else:
            cmd = 'fpzip -d -i ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out') + ' -3 '+ str(w) + ' '  + str(h) + ' ' + str(l)
    else:
        cmd = ' '
    os.system(cmd)
    print ("\n\n\n==="+compressor)
    if compressor == "TTHRESH":
        # f'{globalErr:f}'
        if l == 0:
            #cmd = 'tthresh -i ' + os.path.join(inputDir, 'sf.dat') + ' -t float -s ' + str(1) + ' ' + str(h) + ' ' + str(w) + ' -e ' + f'{globalErr:.10f}' + ' -c ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out')
            cmd = 'tthresh -i ' + os.path.join(inputDir, 'sf.dat') + ' -t float -s ' + str(w) + ' ' + str(h) + ' ' + str(1) + ' -e ' + f'{globalErr:.10f}' + ' -c ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out')
            
        else:
            #cmd = 'tthresh -i ' + os.path.join(inputDir, 'sf.dat') + ' -t float -s ' + str(l) + ' ' + str(h) + ' ' + str(w) + ' -e ' + f'{globalErr:.10f}' + ' -c ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out')
            cmd = 'tthresh -i ' + os.path.join(inputDir, 'sf.dat') + ' -t float -s ' + str(w) + ' ' + str(h) + ' ' + str(l) + ' -e ' + f'{globalErr:.10f}' + ' -c ' + os.path.join(workingDir, 'sf.dat.cmp') + ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out')
        os.system(cmd)
        cmd = 'tthresh -c ' + os.path.join(workingDir, 'sf.dat.cmp')+ ' -o ' + os.path.join(workingDir, 'sf.dat.cmp.out')
        os.system(cmd)
        
    original_size = os.path.getsize(os.path.join(inputDir, 'sf.dat'))
    compressed_size = os.path.getsize(os.path.join(workingDir, 'sf.dat.cmp'))
    sf = np.fromfile(os.path.join(inputDir, 'sf.dat'), dtype='float32')
    sf_d = np.fromfile(os.path.join(workingDir, 'sf.dat.cmp.out'), dtype='float32')
    gErr = max(abs(sf_d - sf))
    psnr = calculatePSNR(sf, sf_d)
    print ("pointwise error")
    print (gErr)
    print ('---')
    #print (original_size/compressed_size)
    return (original_size/compressed_size), gErr, psnr

def runTopoCompressor(inputDir, inputFileName, PersThr, globalErr, scalarField, globalDir, sf, pdmt):
    ts = time.time()
    cmd = 'pvpython ./src/pvTopoCompressor.py ' + os.path.join(inputDir, inputFileName) + ' ' + scalarField + ' ' + os.path.join(globalDir, 'PersThr_' + str(PersThr) + '.ttk') + ' ' + str(PersThr*100) + ' ' + str(globalErr*100)
    os.system(cmd)
    t1 = time.time()-ts
    print ("Compression running time:")
    print (t1)
    original_size = os.path.getsize(os.path.join(inputDir, 'sf.dat'))
    compressed_size = os.path.getsize(os.path.join(globalDir, 'PersThr_' + str(PersThr) + '.ttk') )
    ratio = original_size/compressed_size
    ts = time.time()
    cmd = 'pvpython ./src/pvTopoDecompressor.py ' +  os.path.join(globalDir, 'PersThr_' + str(PersThr) + '.ttk') + ' ' + os.path.join(globalDir, 'PersThr_' + str(PersThr) + '_decompressed.vti')
    os.system(cmd)
    t1 = time.time()-ts
    print ("Decompression running time:")
    print (t1)
    persThrDir = os.path.join(globalDir, 'PersThr_' + str(PersThr))
    make_dir(persThrDir)
    savePersistenceDiagramAndMergeTree(globalDir, 'PersThr_' + str(PersThr) + '_decompressed.vti', 'Decompressed', persThrDir)
    
    sf_d = readScalarFromVTI(os.path.join(globalDir, 'PersThr_' + str(PersThr) + '_decompressed.vti'), 'Decompressed')
    gErr = max(abs(sf_d - sf))
    psnr = calculatePSNR(sf, sf_d)
    return ratio, gErr, psnr


def comparisonWithOtherCmp(inputDir, inputFileName, w, h, l, globalErrs, compressor):
    cmpDir = os.path.join(inputDir, compressor)
    make_dir(cmpDir)
    ratioFile = os.path.join(cmpDir, 'compressionRatio.txt')
    FcntFile = os.path.join(cmpDir, 'FPFNFT.txt')
    gErrFile = os.path.join(cmpDir, 'gErrs.txt')
    psnrFile = os.path.join(cmpDir, 'PSNRs.txt')
    Fcnts = []
    ratios = []
    gErrs = []
    PSNRs = []
    for globalErr in globalErrs:
        rio, gErr, psnr = compressWithCmp(inputDir, cmpDir, w, h, l, globalErr, compressor)
        PSNRs.append(psnr)
        ratios.append(rio)
        gErrs.append(gErr)
        Fcnts.append(checkPerformanceOfSZ(inputDir, inputFileName, w, h, compressor))
    np.savetxt(ratioFile, np.array(ratios), fmt="%.2f")
    np.savetxt(gErrFile, np.array(gErrs), fmt="%.8f")
    np.savetxt(psnrFile, np.array(PSNRs), fmt="%.6f")
    np.savetxt(FcntFile, np.array(Fcnts), fmt="%d")

    ratios = np.loadtxt(ratioFile)
    Fcnts = np.loadtxt(FcntFile)
    figFile = os.path.join(cmpDir, 'Summary.png')
    #plotLineChartForSZ(ratios, Fcnts, globalErrs, figFile)
    cleanFolder(cmpDir)

def comparisonWithTopoCmp(inputDir, inputFileName, PersThrs, globalErrs, scalarField, pdmt):
    cmpDir = os.path.join(inputDir, 'TopoQz')
    make_dir(cmpDir)
    sf = np.fromfile(os.path.join(inputDir, 'sf.dat'), dtype='float32')

    for globalErr in globalErrs:
        globalErrPer = globalErr/max(sf)
        globalDir = os.path.join(cmpDir, 'GlobalErr_' + str(globalErr))
        make_dir(globalDir)
        Fcnts = []
        ratios = []
        gErrs = []
        PSNRs = []
  
        for PersThr in PersThrs:
            ratio, gErr, psnr = runTopoCompressor(inputDir, inputFileName, PersThr, globalErrPer, scalarField, globalDir, sf, pdmt)
            Fcnt = checkPerformanceOfTopoCompressor(inputDir, inputFileName, globalDir, PersThr, scalarField)
            ratios.append(ratio)
            gErrs.append(gErr)
            Fcnts.append(Fcnt)
            PSNRs.append(psnr)
        writeCmpInfo(globalDir, ratios, Fcnts, PSNRs, gErrs)
        figFile = os.path.join(cmpDir, 'GlobalErr_' + str(globalErr)+'.png')
        
        TopoSZebDir = os.path.join(inputDir, 'eb')
        TopoSZebDir = os.path.join(TopoSZebDir, 'GlobalErr_' + str(globalErr))
        TopoSZlbubDir = os.path.join(inputDir, 'lbub')
        TopoSZlbubDir = os.path.join(TopoSZlbubDir, 'GlobalErr_' + str(globalErr))
        cleanFolderTopoQz(globalDir)
        #plotLineChartForTopoCompressor(TopoSZebDir, TopoSZlbubDir, globalDir, PersThrs, globalErr, figFile)

def comparingEBAndUblb(inputDir, inputDir2, globalErrs, PersThrs):
    Rs1 = []
    Rs2 = []
    Ps1 = []
    Ps2 = []
    for globalErr in globalErrs:
        ublbDir = os.path.join(inputDir, 'GlobalErr_' + str(globalErr))
        ebDir = os.path.join(inputDir2, 'GlobalErr_' + str(globalErr))
        ratios1, Fcnts1, PSNRs1, gErrs1 = readCmpInfo(ebDir)
        ratios2, Fcnts2, PSNRs2, gErrs2 = readCmpInfo(ublbDir)
        Rs1.append(ratios1)
        Rs2.append(ratios2)
        Ps1.append(PSNRs1)
        Ps2.append(PSNRs2)
    figFile = os.path.join(inputDir, 'ebVSublb_compressionRatio.png')
    plotLineChartForEbAndUblb(Rs1, Rs2, PersThrs, globalErrs, figFile, 'Compression Ratio')
    figFile = os.path.join(inputDir, 'ebVSublb_PSNR.png')
    plotLineChartForEbAndUblb(Ps1, Ps2, PersThrs, globalErrs, figFile, 'PSNR')
        
